package com.gkutype.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Txt(
    t: String,
    size: Int,
    color: Color = LocalPal.current.text,
    weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier
) {
    BasicText(t, modifier, style = TextStyle(color = color, fontSize = size.sp, fontWeight = weight))
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(
        Modifier.clip(RoundedCornerShape(9.dp))
            .background(if (selected) p.accent else p.panel)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { Txt(text, 14, if (selected) p.onAccent else p.text) }
}
