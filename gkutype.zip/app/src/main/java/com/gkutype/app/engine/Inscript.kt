package com.gkutype.app.engine

import android.view.KeyEvent

/**
 * Hindi Inscript layout. Maps the PHYSICAL key (KeyEvent keyCode) to a Devanagari char.
 * Each value is two chars: [normal, shift]. Same table as the web preview (object L).
 * Z and a few rare keys are not mapped (same as preview, not verified).
 */
object Inscript {
    private val map: Map<Int, String> = mapOf(
        KeyEvent.KEYCODE_1 to "१!",
        KeyEvent.KEYCODE_2 to "२@",
        KeyEvent.KEYCODE_3 to "३#",
        KeyEvent.KEYCODE_4 to "४\$",
        KeyEvent.KEYCODE_5 to "५%",
        KeyEvent.KEYCODE_6 to "६^",
        KeyEvent.KEYCODE_7 to "७&",
        KeyEvent.KEYCODE_8 to "८*",
        KeyEvent.KEYCODE_9 to "९(",
        KeyEvent.KEYCODE_0 to "०)",
        KeyEvent.KEYCODE_Q to "ौऔ",
        KeyEvent.KEYCODE_W to "ैऐ",
        KeyEvent.KEYCODE_E to "ाआ",
        KeyEvent.KEYCODE_R to "ीई",
        KeyEvent.KEYCODE_T to "ूऊ",
        KeyEvent.KEYCODE_Y to "बभ",
        KeyEvent.KEYCODE_U to "हङ",
        KeyEvent.KEYCODE_I to "गघ",
        KeyEvent.KEYCODE_O to "दध",
        KeyEvent.KEYCODE_P to "जझ",
        KeyEvent.KEYCODE_LEFT_BRACKET to "डढ",
        KeyEvent.KEYCODE_RIGHT_BRACKET to "़ञ",
        KeyEvent.KEYCODE_A to "ोओ",
        KeyEvent.KEYCODE_S to "ेए",
        KeyEvent.KEYCODE_D to "्अ",
        KeyEvent.KEYCODE_F to "िइ",
        KeyEvent.KEYCODE_G to "ुउ",
        KeyEvent.KEYCODE_H to "पफ",
        KeyEvent.KEYCODE_J to "रऱ",
        KeyEvent.KEYCODE_K to "कख",
        KeyEvent.KEYCODE_L to "तथ",
        KeyEvent.KEYCODE_SEMICOLON to "चछ",
        KeyEvent.KEYCODE_APOSTROPHE to "टठ",
        KeyEvent.KEYCODE_X to "ंँ",
        KeyEvent.KEYCODE_C to "मण",
        KeyEvent.KEYCODE_V to "नन",
        KeyEvent.KEYCODE_B to "वव",
        KeyEvent.KEYCODE_N to "लळ",
        KeyEvent.KEYCODE_M to "सश",
        KeyEvent.KEYCODE_COMMA to ",ष",
        KeyEvent.KEYCODE_PERIOD to ".।",
        KeyEvent.KEYCODE_SLASH to "यय",
        KeyEvent.KEYCODE_SPACE to "  "
    )

    /** Returns the Devanagari char for this key, or null if the key is not part of the layout. */
    fun charFor(keyCode: Int, shift: Boolean): Char? {
        val s = map[keyCode] ?: return null
        return s[if (shift) 1 else 0]
    }
}
