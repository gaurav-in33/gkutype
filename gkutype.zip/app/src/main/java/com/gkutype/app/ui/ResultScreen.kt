package com.gkutype.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun Btn(text: String, primary: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(
        Modifier.clip(RoundedCornerShape(10.dp))
            .background(if (primary) p.accent else p.panel)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) { Txt(text, 15, if (primary) p.onAccent else p.text, FontWeight.SemiBold) }
}

/** Shown for mistyped keys: matras get a dotted circle so they are visible on their own. */
fun keyLabel(c: Char): String = when {
    c in 'a'..'z' -> c.uppercase()
    (c in 'ऀ'..'ः') || (c in 'ऺ'..'ॏ') -> "◌" + c
    else -> c.toString()
}

private class Pt(val sec: Float, val wpm: Float, val raw: Float, val newErr: Boolean)

/** Points for the graph. Same maths as the preview: wpm = correct/5/min, raw = keystrokes/5/min. */
private fun graphPoints(samples: List<Sample>): List<Pt> {
    val out = ArrayList<Pt>()
    var prevMistakes = 0
    for (q in samples) {
        if (q.sec < 1f) continue
        val min = q.sec / 60f
        out.add(Pt(q.sec, q.correct / 5f / min, q.keystrokes / 5f / min, q.mistakes > prevMistakes))
        prevMistakes = q.mistakes
    }
    return out
}

@Composable
private fun Cell(value: String, label: String, modifier: Modifier, color: Color? = null) {
    val p = LocalPal.current
    Column(modifier) {
        Txt(value, 20, color ?: p.text, FontWeight.SemiBold)
        Txt(label, 12, p.dim)
    }
}

@Composable
private fun Graph(r: TestResult) {
    val p = LocalPal.current
    val pts = remember(r) { graphPoints(r.game.samples) }
    if (pts.size < 2) return
    var mx = 10f
    for (q in pts) if (q.raw > mx) mx = q.raw
    val total = pts[pts.size - 1].sec

    Canvas(Modifier.fillMaxWidth().height(70.dp)) {
        val w = size.width
        val h = size.height
        val pad = 4.dp.toPx()
        val usable = h - 2.5f * pad
        val wp = Path()
        val rp = Path()
        for (i in pts.indices) {
            val q = pts[i]
            val x = q.sec / total * w
            val yw = h - pad - q.wpm / mx * usable
            val yr = h - pad - q.raw / mx * usable
            if (i == 0) {
                wp.moveTo(x, yw)
                rp.moveTo(x, yr)
            } else {
                wp.lineTo(x, yw)
                rp.lineTo(x, yr)
            }
        }
        drawPath(
            rp, p.pending,
            style = Stroke(width = 1.5f.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(3.dp.toPx(), 3.dp.toPx())))
        )
        drawPath(
            wp, p.accent,
            style = Stroke(width = 2.2f.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        for (q in pts) {
            if (q.newErr) drawCircle(p.bad, 2.6f.dp.toPx(), Offset(q.sec / total * w, h - 3.dp.toPx()))
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Row {
            Txt("—", 12, p.accent, FontWeight.Bold)
            Txt(" wpm   ", 12, p.dim)
            Txt("- -", 12, p.pending)
            Txt(" raw   ", 12, p.dim)
            Txt("●", 12, p.bad)
            Txt(" errors", 12, p.dim)
        }
        Txt(r.seconds.toString() + "s", 12, p.dim)
    }
}

@Composable
fun ResultScreen(r: TestResult, onRestart: () -> Unit, onBack: () -> Unit) {
    val p = LocalPal.current

    // Weak keys of THIS test (letters merged upper/lower case), top 3.
    val weak = remember(r) {
        val m = HashMap<Char, Int>()
        for ((c, n) in r.game.engine.missCount) {
            val k = if (c.code < 128) c.lowercaseChar() else c
            m[k] = (m[k] ?: 0) + n
        }
        m.entries.sortedByDescending { en -> en.value }.take(3).joinToString("   ") { en -> keyLabel(en.key) }
    }

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val minH = maxHeight
        Row(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).heightIn(min = minH)
                .padding(horizontal = 28.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(26.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(0.7f)) {
                Txt(r.wpm.toString(), 88, p.accent, FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Txt("WPM", 16, p.dim)
                    if (r.newBest) {
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.clip(RoundedCornerShape(50)).background(p.accent).padding(horizontal = 9.dp, vertical = 2.dp)) {
                            Txt("New best", 12, p.onAccent, FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Txt(r.raw.toString(), 22, p.text, FontWeight.SemiBold)
                    Txt(" raw wpm", 13, p.dim)
                }
                Spacer(Modifier.height(4.dp))
                Txt(r.label, 13, p.dim)
            }
            Column(Modifier.weight(1.5f)) {
                Row(Modifier.fillMaxWidth()) {
                    Cell(fmt1(r.accuracy) + "%", "accuracy", Modifier.weight(1f))
                    Cell(r.wrong.toString(), "wrong", Modifier.weight(1f), p.bad)
                    Cell(r.skipped.toString(), "skipped chars", Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    Cell(r.keystrokes.toString(), "keystrokes", Modifier.weight(1f))
                    Cell(r.correct.toString(), "correct chars", Modifier.weight(1f))
                    Cell(r.seconds.toString() + "s", "time", Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Graph(r)
                if (weak.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Txt("Weak keys: $weak", 14, p.bad)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Restart test", true, onRestart)
                    Btn("Back", false, onBack)
                }
                Spacer(Modifier.height(8.dp))
                Txt("Enter restart · Esc back · Space skips the rest of a word", 12, p.pending)
            }
        }
    }
}
