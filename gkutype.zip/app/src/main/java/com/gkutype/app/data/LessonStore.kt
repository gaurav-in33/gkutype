package com.gkutype.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Course progress: best accuracy per level and the last level you practised (for the Continue card).
 * Keys look like "en:0" or "hi:3". Saved only when a lesson finishes or you start one.
 */
class LessonStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("gku_lessons", Context.MODE_PRIVATE)

    var best by mutableStateOf(load())
        private set

    var lastKey by mutableStateOf(sp.getString("last", "en:0") ?: "en:0")
        private set

    fun bestFor(key: String): Float = best[key] ?: 0f

    fun setLast(key: String) {
        if (key == lastKey) return
        lastKey = key
        sp.edit().putString("last", key).apply()
    }

    fun record(key: String, acc: Float) {
        if (acc <= bestFor(key)) return
        val m = HashMap<String, Float>(best)
        m[key] = acc
        best = m
        val sb = StringBuilder()
        for ((k, v) in m) sb.append(k).append('=').append(v).append(';')
        sp.edit().putString("best", sb.toString()).apply()
    }

    private fun load(): Map<String, Float> {
        val out = HashMap<String, Float>()
        val s = sp.getString("best", "") ?: ""
        for (part in s.split(';')) {
            if (part.isEmpty()) continue
            try {
                val f = part.split('=')
                out[f[0]] = f[1].toFloat()
            } catch (e: Exception) {
                // skip a damaged entry
            }
        }
        return out
    }
}
