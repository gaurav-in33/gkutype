package com.gkutype.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gkutype.app.data.LessonStore
import com.gkutype.app.engine.Lessons

private fun splitKey(key: String): Pair<String, Int> {
    val a = key.split(':')
    val t = if (a[0] == Lessons.HI) Lessons.HI else Lessons.EN
    val i = a.getOrNull(1)?.toIntOrNull() ?: 0
    val n = Lessons.defs(t).size
    return Pair(t, if (i in 0 until n) i else 0)
}

@Composable
fun LearnScreen(lessons: LessonStore, onStart: (String, Int) -> Unit) {
    val p = LocalPal.current
    val last = splitKey(lessons.lastKey)
    var tab by remember { mutableStateOf(last.first) }
    val defs = Lessons.defs(tab)
    val lastDef = Lessons.defs(last.first)[last.second]
    val lastBest = lessons.bestFor(last.first + ":" + last.second)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 26.dp, vertical = 18.dp)
    ) {
        Txt("Touch typing course", 18, p.text, FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))

        // Continue card
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(p.panel).padding(14.dp)) {
            Row {
                Txt("Continue", 15, p.text, FontWeight.SemiBold)
                Txt(
                    "   " + Lessons.name(last.first) + " · Level " + (last.second + 1) + " · " + lastDef.title,
                    14, p.dim
                )
            }
            Box(Modifier.fillMaxWidth().padding(vertical = 10.dp).height(6.dp).clip(RoundedCornerShape(4.dp)).background(p.line)) {
                val f = (lastBest / 100f).coerceIn(0f, 1f)
                if (f > 0f) Box(Modifier.fillMaxWidth(f).height(6.dp).clip(RoundedCornerShape(4.dp)).background(p.accent))
            }
            Btn("Continue", true) { onStart(last.first, last.second) }
        }
        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("English", tab == Lessons.EN) { tab = Lessons.EN }
            Chip("Hindi", tab == Lessons.HI) { tab = Lessons.HI }
        }
        Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(p.panel).padding(14.dp)) {
            Txt(
                "Every level is open, so start anywhere. Aim for 95% accuracy in each. The finger guide keyboard shows in lessons.",
                13, p.dim
            )
        }
        Spacer(Modifier.height(4.dp))

        defs.forEachIndexed { i, d ->
            val b = lessons.bestFor(tab + ":" + i)
            val passed = b >= d.target
            Row(
                Modifier.fillMaxWidth().clickable { onStart(tab, i) }.padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Txt((i + 1).toString() + ". " + d.title, 15, p.text)
                val st = if (passed) "Passed " + b.toInt() + "%"
                else if (b > 0f) "Best " + b.toInt() + "% · continue"
                else "Open"
                Txt(st, 14, if (passed) p.accent else p.dim)
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(p.line))
        }
        Spacer(Modifier.height(12.dp))
    }
}
