package com.gkutype.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gkutype.app.data.StatsStore

@Composable
private fun StatCard(content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(p.panel).padding(14.dp),
        content = content
    )
}

@Composable
private fun Tag(text: String, on: Boolean) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(9.dp)
    val m = if (on) Modifier.clip(shape).background(p.accent)
    else Modifier.clip(shape).border(1.dp, p.line, shape)
    Box(m.padding(horizontal = 12.dp, vertical = 6.dp)) {
        Txt(text, 14, if (on) p.onAccent else p.text)
    }
}

@Composable
private fun Big(value: String, label: String) {
    val p = LocalPal.current
    Column {
        Txt(value, 26, p.text, FontWeight.SemiBold)
        Txt(label, 12, p.dim)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StatsScreen(store: StatsStore) {
    val p = LocalPal.current
    val h = store.history
    val last = if (h.size > 7) h.subList(h.size - 7, h.size) else h
    var mx = 1
    for (r in last) if (r.wpm > mx) mx = r.wpm
    val top = store.misses.entries.filter { en -> en.value > 0 }.sortedByDescending { en -> en.value }.take(6)
    val ach = listOf(
        "First 20 WPM" to (store.bestWpm >= 20),
        "30 WPM" to (store.bestWpm >= 30),
        "50 WPM" to (store.bestWpm >= 50),
        "10 tests" to (store.tests >= 10),
        "99% accuracy" to (store.bestAcc >= 99f)
    )

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 26.dp, vertical = 18.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Txt("Progress", 18, p.text, FontWeight.SemiBold)
            Txt("  · saved on this phone only", 13, p.dim)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard {
                    Txt(if (last.isEmpty()) "Last tests (WPM)" else "Last ${last.size} tests (WPM)", 13, p.dim)
                    Spacer(Modifier.height(10.dp))
                    if (last.isEmpty()) {
                        Txt("No tests yet. Finish a test to see your progress.", 14, p.pending)
                    } else {
                        Row(
                            Modifier.fillMaxWidth().height(110.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.Bottom
                        ) {
                            last.forEachIndexed { i, r ->
                                val bh = maxOf(30f, r.wpm.toFloat() / mx * 100f)
                                Box(
                                    Modifier.weight(1f).height(bh.dp)
                                        .clip(RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp))
                                        .background(p.accent),
                                    contentAlignment = Alignment.TopCenter
                                ) {
                                    Txt(r.wpm.toString() + "\n" + (i + 1), 11, p.onAccent, FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
                StatCard {
                    Txt("Most mistyped keys", 13, p.dim)
                    Spacer(Modifier.height(6.dp))
                    if (top.isEmpty()) {
                        Txt("No mistakes yet", 13, p.pending)
                    } else {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            top.forEach { en -> Tag(keyLabel(en.key) + " · " + en.value, false) }
                        }
                    }
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                        Big(store.lastWpm.toString(), "Last WPM")
                        Big(store.bestWpm.toString(), "Best")
                        Big(store.averageWpm.toString(), "Average")
                        Big(store.tests.toString(), "Tests")
                    }
                }
                StatCard {
                    Txt("Achievements", 13, p.dim)
                    Spacer(Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ach.forEach { a -> Tag(a.first, a.second) }
                    }
                }
            }
        }
    }
}
