package com.gkutype.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gkutype.app.data.Prefs

@Composable
private fun SetRow(label: String, content: @Composable () -> Unit) {
    val p = LocalPal.current
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Txt(label, 15, p.text)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                content()
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.line))
    }
}

@Composable
fun SettingsScreen(prefs: Prefs) {
    val p = LocalPal.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 26.dp, vertical = 18.dp)
    ) {
        Txt("Settings", 18, p.text, FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))

        SetRow("Theme") {
            Chip("Dark", prefs.theme == "dark") { prefs.changeTheme("dark") }
            Chip("Light", prefs.theme == "light") { prefs.changeTheme("light") }
        }
        SetRow("Text size") {
            Chip("−", false) { if (prefs.textSize > 20) prefs.changeTextSize(prefs.textSize - 2) }
            Box(Modifier.width(36.dp), contentAlignment = Alignment.Center) { Txt(prefs.textSize.toString(), 15, p.text) }
            Chip("+", false) { if (prefs.textSize < 40) prefs.changeTextSize(prefs.textSize + 2) }
        }
        SetRow("Finger guide keyboard") {
            Chip("Lessons", prefs.guide == "lessons") { prefs.changeGuide("lessons") }
            Chip("Always", prefs.guide == "always") { prefs.changeGuide("always") }
            Chip("Off", prefs.guide == "off") { prefs.changeGuide("off") }
        }
        SetRow("Cursor") {
            Chip("Block", prefs.cursor == "block") { prefs.changeCursor("block") }
            Chip("Underline", prefs.cursor == "underline") { prefs.changeCursor("underline") }
        }
        SetRow("Hindi layout") { Txt("Inscript", 15, p.dim) }
        SetRow("Wrong key") {
            Chip("Keep going", !prefs.stopOnError) { prefs.changeStopOnError(false) }
            Chip("Stop on error", prefs.stopOnError) { prefs.changeStopOnError(true) }
        }
        SetRow("Low motion (less heat)") {
            Chip("Off", !prefs.lowMotion) { prefs.changeLowMotion(false) }
            Chip("On", prefs.lowMotion) { prefs.changeLowMotion(true) }
        }

        Spacer(Modifier.height(20.dp))
        AboutCard()
        Spacer(Modifier.height(16.dp))
    }
}

private val AMBER_A = Color(0xFFFFA92E)
private val AMBER_B = Color(0xFFF08A0C)

@Composable
private fun KeyChip(text: String, hot: Boolean) {
    val shape = RoundedCornerShape(7.dp)
    val shadow = if (hot) Color(0xFFB96A00) else Color.Black
    Box(
        Modifier.drawBehind {
            drawRoundRect(shadow, Offset(0f, 3.dp.toPx()), size, androidx.compose.ui.geometry.CornerRadius(7.dp.toPx()))
        }
            .clip(shape)
            .then(
                if (hot) Modifier.background(Brush.verticalGradient(listOf(AMBER_A, AMBER_B)))
                else Modifier.background(Color(0xFF1E1B17)).border(1.dp, Color(0xFF4A443B), shape)
            )
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Txt(text, 11, if (hot) Color(0xFF1A1206) else Color(0xFFF5F1E8), FontWeight.Bold)
    }
}

@Composable
private fun AboutCard() {
    val p = LocalPal.current
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier.fillMaxWidth().clip(shape).background(p.panel)
            .border(1.dp, Color(0xFFF2A33A).copy(alpha = 0.53f), shape)
    ) {
        // dot-grid texture, fading in from the middle to the right
        Canvas(Modifier.matchParentSize()) {
            val step = 14.dp.toPx()
            val r = 1.5f.dp.toPx()
            val x0 = size.width * 0.45f
            val span = size.width - x0
            var x = x0
            while (x < size.width) {
                val fade = ((x - x0) / (span * 0.8f)).coerceIn(0f, 1f)
                var y = step / 2
                while (y < size.height) {
                    drawCircle(Color(0xFFF2A33A).copy(alpha = 0.33f * fade), r, Offset(x, y))
                    y += step
                }
                x += step
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                BasicText(
                    "APP DEVELOPER",
                    style = TextStyle(color = p.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.2.sp)
                )
                Spacer(Modifier.height(2.dp))
                BasicText(
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = p.text)) { append("Gaurav") }
                        withStyle(SpanStyle(color = AMBER_B)) { append(".") }
                    },
                    style = TextStyle(fontSize = 36.sp, fontWeight = FontWeight.Black)
                )
                Spacer(Modifier.height(7.dp))
                Box(
                    Modifier.width(60.dp).height(3.dp).clip(RoundedCornerShape(3.dp))
                        .background(Brush.horizontalGradient(listOf(AMBER_A, AMBER_B)))
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    KeyChip("v1.0", true)
                    KeyChip("Offline", false)
                    KeyChip("No ads", false)
                    KeyChip("No tracking", false)
                }
                Spacer(Modifier.height(14.dp))
                Row {
                    Txt("Made with ", 12, p.dim)
                    Txt("♥", 12, Color(0xFFE0457B), FontWeight.Bold)
                    Txt(" in India", 12, p.dim)
                }
            }
            GkuLogo(92.dp)
        }
    }
}
