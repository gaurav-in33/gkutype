package com.gkutype.app.engine

import kotlin.random.Random

/** One course level: a title, the accuracy target (%) and a text generator (new text each attempt). */
class LessonDef(val title: String, val target: Int, val make: () -> String)

/** Learn course: English 12 levels, Hindi 6 levels. All levels are open. Same content as the preview (EL/HL/EG/HG2). */
object Lessons {
    const val EN = "en"
    const val HI = "hi"

    private val rnd = Random.Default

    private fun gen(keys: String, n: Int): String {
        val sb = StringBuilder()
        for (i in 0 until n) {
            if (i > 0) sb.append(' ')
            val m = 2 + rnd.nextInt(4)
            for (j in 0 until m) sb.append(keys[rnd.nextInt(keys.length)])
        }
        return sb.toString()
    }

    private fun pick(list: List<String>, n: Int): String {
        val out = ArrayList<String>(n)
        var prev = ""
        while (out.size < n) {
            val w = list[rnd.nextInt(list.size)]
            if (w != prev || list.size == 1) {
                out.add(w)
                prev = w
            }
        }
        return out.joinToString(" ")
    }

    private fun cap(w: String): String = w.substring(0, 1).uppercase() + w.substring(1)

    private fun sentences(q: List<String>): String {
        val a = q.shuffled()
        val b = q.shuffled()
        return (a + b).joinToString(" ")
    }

    private fun words(s: String): List<String> = s.split(' ').filter { it.isNotEmpty() }

    private val hiH1 = words("चुप रुक कोच पेच रेत तेरे पुर कर पर तक चिर पिक कुत परे तप कप")
    private val hiH2 = words("बाग हार बीज गीत दादा जीत दीदी गाजर बाजा बादल")
    private val hiBottom = words("नमन वन नयन सवन सम समय मनन मन सब")

    val english: List<LessonDef> = listOf(
        LessonDef("F and J", 95) { gen("fj", 100) },
        LessonDef("Home row", 95) { gen("asdfjkl;", 100) },
        LessonDef("Top row", 95) { gen("qwertyuiopasdfjkl", 100) },
        LessonDef("Bottom row", 95) { gen("zxcvbnm,./asdfjkl", 100) },
        LessonDef("Numbers", 95) { gen("1234567890asdfjkl", 100) },
        LessonDef("Symbols", 95) { gen(",.;'/?asdfjkl", 100) },
        LessonDef("Capitals and Shift", 95) { pick(Words.english, 70).split(' ').joinToString(" ") { cap(it) } },
        LessonDef("Words", 95) { pick(Words.english, 100) },
        LessonDef("Sentences", 95) { sentences(Words.quotesEnglish) },
        LessonDef("Paragraphs", 95) { pick(Words.english, 180) },
        LessonDef("Speed building", 95) { pick(Words.english, 160) },
        LessonDef("Accuracy training", 98) { pick(Words.english, 70) }
    )

    val hindi: List<LessonDef> = listOf(
        LessonDef("Home row · प र क त च", 95) { pick(hiH1, 100) },
        LessonDef("Top row · ा ी ू ब ह ग द ज", 95) { pick(hiH2, 100) },
        LessonDef("Bottom row · ं म न व ल स य", 95) { pick(hiBottom, 100) },
        LessonDef("Matras and half letters", 95) { pick(hiH1 + hiH2, 100) },
        LessonDef("Words", 95) { pick(Words.hindi, 100) },
        LessonDef("Sentences", 95) { sentences(Words.quotesHindi) }
    )

    fun defs(track: String): List<LessonDef> = if (track == HI) hindi else english
    fun name(track: String): String = if (track == HI) "Hindi" else "English"
}
