package com.gkutype.app.ui

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.input.InputManager
import android.text.StaticLayout
import android.text.TextPaint
import android.view.InputDevice
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gkutype.app.data.Prefs
import com.gkutype.app.engine.KeyRouter
import com.gkutype.app.engine.TypingEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.roundToInt

private fun hasPhysicalKeyboard(): Boolean {
    for (id in InputDevice.getDeviceIds()) {
        val d = InputDevice.getDevice(id) ?: continue
        if (!d.isVirtual &&
            (d.sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD &&
            d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
        ) return true
    }
    return false
}

@Composable
fun TypeScreen(session: TypeSession, prefs: Prefs) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val g = session.game
    val res = session.result
    var toast by remember { mutableStateOf<String?>(null) }

    // Hardware keys go to the session; also watch for a USB keyboard being plugged in or out.
    DisposableEffect(session) {
        KeyRouter.handler = { e -> session.onKey(e) }
        val im = ctx.getSystemService(Context.INPUT_SERVICE) as InputManager
        val l = object : InputManager.InputDeviceListener {
            override fun onInputDeviceAdded(deviceId: Int) { session.hasKeyboard = hasPhysicalKeyboard() }
            override fun onInputDeviceRemoved(deviceId: Int) { session.hasKeyboard = hasPhysicalKeyboard() }
            override fun onInputDeviceChanged(deviceId: Int) { session.hasKeyboard = hasPhysicalKeyboard() }
        }
        session.hasKeyboard = hasPhysicalKeyboard()
        im.registerInputDeviceListener(l, null)
        onDispose {
            im.unregisterInputDeviceListener(l)
            KeyRouter.handler = null
            session.abandon()
        }
    }

    // One tick per second, only while a test is running.
    LaunchedEffect(g, g.started) {
        if (g.started) {
            while (isActive && !g.finished) {
                delay(1000L - g.elapsed() % 1000L)
                if (g.finished) break
                if (g.tick()) {
                    session.complete()
                    break
                }
            }
        }
    }

    val hidden = session.barsHidden
    val live = !hidden
    val spec: AnimationSpec<Float> = if (prefs.lowMotion) snap() else tween(250)
    val a by animateFloatAsState(targetValue = if (hidden) 0f else 1f, animationSpec = spec, label = "bars")

    Box(Modifier.fillMaxSize()) {
        if (res != null) {
            ResultPlaceholder(res, onRestart = { session.newGame() }, onBack = { session.newGame() })
        } else {
            Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 8.dp)) {
                Box(Modifier.fillMaxWidth().alpha(a)) {
                    ConfigBar(session, live) { m -> toast = m }
                }
                if (!session.hasKeyboard) {
                    Box(Modifier.fillMaxWidth().padding(top = 6.dp), contentAlignment = Alignment.Center) {
                        Txt("Connect a USB keyboard (OTG) to start typing", 13, p.accent, FontWeight.SemiBold)
                    }
                }
                Column(
                    Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.Center
                ) {
                    StatsRow(g, 1f - a)
                    Spacer(Modifier.height(8.dp))
                    TextArea(g, prefs)
                }
                Box(Modifier.fillMaxWidth().alpha(a)) { BottomBar(session, live) }
            }
        }

        val t = toast
        if (t != null) {
            LaunchedEffect(t) {
                delay(2200L)
                toast = null
            }
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp)
                    .clip(RoundedCornerShape(10.dp)).background(p.panel)
                    .padding(horizontal = 16.dp, vertical = 9.dp)
            ) { Txt(t, 14, p.text) }
        }
    }
}

// ---------- small pieces ----------

@Composable
private fun Group(content: @Composable RowScope.() -> Unit) {
    val p = LocalPal.current
    Row(
        Modifier.clip(RoundedCornerShape(10.dp)).background(p.panel).padding(horizontal = 4.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
private fun Opt(text: String, on: Boolean, live: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(Modifier.clickable(enabled = live, onClick = onClick).padding(horizontal = 9.dp, vertical = 6.dp)) {
        Txt(text, 13, if (on) p.accent else p.pending, if (on) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun ConfigBar(s: TypeSession, live: Boolean, onToast: (String) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val minW = maxWidth
        Row(
            Modifier.horizontalScroll(rememberScrollState()).widthIn(min = minW).padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Group {
                Opt("@ punctuation", s.pun, live) { s.togglePun() }
                Opt("# numbers", s.num, live) { s.toggleNum() }
                Opt("✦ weak keys", s.weak, live) { s.toggleWeak() }
            }
            Group {
                Opt("◷ time", s.mode == "time", live) { s.changeMode("time") }
                Opt("A words", s.mode == "words", live) { s.changeMode("words") }
                Opt("❝ quote", s.mode == "quote", live) { s.changeMode("quote") }
            }
            if (s.mode != "quote") {
                val isTime = s.mode == "time"
                val presets = if (isTime) listOf(15, 30, 60, 120) else listOf(10, 25, 50, 100)
                val cur = if (isTime) s.dur else s.wc
                val isPreset = presets.contains(cur)
                Group {
                    presets.forEach { v ->
                        Opt(v.toString(), cur == v, live) { if (isTime) s.changeDur(v) else s.changeWords(v) }
                    }
                    if (s.customOpen) {
                        CustomField(isTime, s, onToast)
                    } else {
                        Opt("✎ " + (if (isPreset) "custom" else cur.toString()), !isPreset, live) {
                            s.customOpen = true
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomField(isTime: Boolean, s: TypeSession, onToast: (String) -> Unit) {
    val p = LocalPal.current
    var text by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val fm = LocalFocusManager.current

    fun submit() {
        val n = text.toIntOrNull()
        if (n == null || n < 1) {
            onToast("Enter a number first.")
            return
        }
        val lo = 5
        val hi = if (isTime) 600 else 500
        val v = n.coerceIn(lo, hi)
        if (v != n) onToast((if (isTime) "Time" else "Words") + " must be " + lo + " to " + hi + ".")
        fm.clearFocus()
        if (isTime) s.changeDur(v) else s.changeWords(v)
    }

    LaunchedEffect(Unit) {
        try {
            focus.requestFocus()
        } catch (e: Exception) {
        }
    }

    BasicTextField(
        value = text,
        onValueChange = { v -> text = v.filter { ch -> ch.isDigit() }.take(4) },
        singleLine = true,
        textStyle = TextStyle(color = p.text, fontSize = 13.sp),
        cursorBrush = SolidColor(p.accent),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { submit() }),
        modifier = Modifier.width(76.dp).focusRequester(focus),
        decorationBox = { inner ->
            Box(Modifier.clip(RoundedCornerShape(6.dp)).background(p.bg).padding(horizontal = 8.dp, vertical = 5.dp)) {
                if (text.isEmpty()) Txt(if (isTime) "seconds" else "words", 13, p.pending)
                inner()
            }
        }
    )
    Opt("ok", true, true) { submit() }
}

@Composable
private fun BottomBar(s: TypeSession, live: Boolean) {
    val p = LocalPal.current
    Row(
        Modifier.fillMaxWidth().height(40.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.clickable(enabled = live) { s.newGame() }.padding(horizontal = 12.dp, vertical = 4.dp)) {
            Txt("↻", 22, p.pending)
        }
        Row {
            Opt("english", s.lang == "english", live) { s.changeLang("english") }
            Opt("hindi", s.lang == "hindi", live) { s.changeLang("hindi") }
            Opt("hinglish", s.lang == "hinglish", live) { s.changeLang("hinglish") }
        }
    }
}

@Composable
private fun Stat(value: String, unit: String, accent: Boolean) {
    val p = LocalPal.current
    Column {
        Txt(value, 22, if (accent) p.accent else p.text, FontWeight.SemiBold)
        Txt(unit, 12, p.dim)
    }
}

@Composable
private fun StatsRow(g: Game, alpha: Float) {
    Row(
        Modifier.fillMaxWidth().alpha(alpha),
        horizontalArrangement = Arrangement.spacedBy(26.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Stat(g.timeTxt, " ", true)
        Stat(g.wpmNow.toString(), "wpm", false)
        Stat(fmt1(g.accNow) + "%", "acc", false)
        Stat(g.errNow.toString(), "err", false)
    }
}

// ---------- the 3-line text area ----------

/** Greedy line wrap (same engine Compose uses), returns line start offsets + text length at the end. */
private fun wrapLines(text: String, widthPx: Int, sizePx: Float, hindi: Boolean): IntArray {
    val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    paint.textSize = sizePx
    paint.typeface = if (hindi) Typeface.DEFAULT else Typeface.MONOSPACE
    val w = if (widthPx < 100) 100 else widthPx
    val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, w).setIncludePad(false).build()
    val n = layout.lineCount
    val starts = IntArray(n + 1)
    for (i in 0 until n) starts[i] = layout.getLineStart(i)
    starts[n] = text.length
    return starts
}

private fun lineOf(starts: IntArray, idx: Int): Int {
    var lo = 0
    var hi = starts.size - 2
    while (lo < hi) {
        val mid = (lo + hi + 1) ushr 1
        if (starts[mid] <= idx) lo = mid else hi = mid - 1
    }
    return lo
}

private fun styleKey(e: TypingEngine, j: Int): Int =
    if (j == e.pos && !e.done) 4 else e.state[j].toInt()

private fun buildLine(e: TypingEngine, from: Int, to: Int, p: Pal, underline: Boolean): AnnotatedString {
    val t = e.text
    return buildAnnotatedString {
        var j = from
        while (j < to) {
            val k = styleKey(e, j)
            var m = j + 1
            while (m < to && styleKey(e, m) == k) m++
            val st = when (k) {
                1 -> SpanStyle(color = p.text)
                2 -> SpanStyle(color = p.bad, background = p.bad.copy(alpha = 0.22f))
                3 -> SpanStyle(color = p.pending.copy(alpha = 0.4f), textDecoration = TextDecoration.Underline)
                4 -> if (underline) SpanStyle(color = p.accent, textDecoration = TextDecoration.Underline)
                     else SpanStyle(color = p.onAccent, background = p.accent)
                else -> SpanStyle(color = p.pending)
            }
            withStyle(st) { append(t.substring(j, m)) }
            j = m
        }
    }
}

@Composable
private fun LineText(g: Game, from: Int, to: Int, size: Int, underline: Boolean) {
    val p = LocalPal.current
    val e = g.engine
    var v = 0
    for (j in from until to) {
        if (e.stamp[j] > v) v = e.stamp[j]
    }
    val s = remember(g, from, to, v, p, underline) { buildLine(e, from, to, p, underline) }
    BasicText(
        text = s,
        style = TextStyle(
            color = p.pending,
            fontSize = size.sp,
            fontFamily = if (g.hindi) FontFamily.Default else FontFamily.Monospace,
            lineHeight = (size * 1.7f).sp
        ),
        softWrap = false,
        maxLines = 1
    )
}

@Composable
private fun TextArea(g: Game, prefs: Prefs) {
    val d = LocalDensity.current
    val size = prefs.textSize
    val lhPx = with(d) { (size * 1.7f).sp.toPx() }
    val lhDp: Dp = with(d) { (size * 1.7f).sp.toDp() }
    val underline = prefs.cursor == "underline"

    BoxWithConstraints(Modifier.fillMaxWidth().height(lhDp * 3).clipToBounds()) {
        val wPx = with(d) { maxWidth.toPx() }.toInt()
        val szPx = with(d) { size.sp.toPx() }
        val starts = remember(g, wPx, szPx) { wrapLines(g.engine.text, wPx, szPx, g.hindi) }
        val lineCount = starts.size - 1
        val ver = g.version // read so this area redraws after each keystroke
        val e = g.engine
        val cur = lineOf(starts, if (e.pos < e.length) e.pos else e.length - 1)
        val top = if (cur > 1) cur - 1 else 0
        val scroll = remember(g, starts) { Animatable(0f) }

        LaunchedEffect(g, starts, top, lhPx, prefs.lowMotion) {
            val target = top * lhPx
            if (prefs.lowMotion) scroll.snapTo(target) else scroll.animateTo(target, tween(120))
        }

        val first = if (top - 1 > 0) top - 1 else 0
        val last = if (top + 3 < lineCount - 1) top + 3 else lineCount - 1
        if (ver >= 0 && lineCount > 0) {
            for (i in first..last) {
                key(i) {
                    Box(
                        Modifier
                            .offset { IntOffset(0, (i * lhPx - scroll.value).roundToInt()) }
                            .fillMaxWidth()
                            .height(lhDp)
                    ) {
                        LineText(g, starts[i], starts[i + 1], size, underline)
                    }
                }
            }
        }
    }
}

// ---------- simple result (real Result screen comes in Part 3) ----------

@Composable
private fun Btn(text: String, primary: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(
        Modifier.clip(RoundedCornerShape(10.dp))
            .background(if (primary) p.accent else p.panel)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) { Txt(text, 15, if (primary) p.onAccent else p.text, FontWeight.SemiBold) }
}

@Composable
private fun ResultPlaceholder(r: TestResult, onRestart: () -> Unit, onBack: () -> Unit) {
    val p = LocalPal.current
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Txt(r.wpm.toString(), 88, p.accent, FontWeight.Bold)
        Txt(if (r.newBest) "WPM · New best" else "WPM", 16, p.dim)
        Spacer(Modifier.height(10.dp))
        Txt(fmt1(r.accuracy) + "% accuracy · " + r.wrong + " wrong · raw " + r.raw + " wpm", 15, p.text)
        Spacer(Modifier.height(2.dp))
        Txt(r.label, 13, p.dim)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("Restart test", true, onRestart)
            Btn("Back", false, onBack)
        }
        Spacer(Modifier.height(8.dp))
        Txt("Enter restart · Esc back", 12, p.pending)
    }
}
