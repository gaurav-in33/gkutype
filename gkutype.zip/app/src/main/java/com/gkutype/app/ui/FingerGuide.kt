package com.gkutype.app.ui

import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.gkutype.app.engine.Inscript

// finger: 0 pinky, 1 ring, 2 middle, 3 index, 4 thumb
private class GK(val code: Int, val en: String, val f: Int)

private val FINGER_COLORS = arrayOf(
    Color(0xFFB58AE0), Color(0xFF6FA8E8), Color(0xFF6FCB8F), Color(0xFFE8B04A), Color(0xFF888888)
)

private val ROWS: List<List<GK>> = listOf(
    listOf(
        GK(KeyEvent.KEYCODE_1, "1", 0), GK(KeyEvent.KEYCODE_2, "2", 1), GK(KeyEvent.KEYCODE_3, "3", 2),
        GK(KeyEvent.KEYCODE_4, "4", 3), GK(KeyEvent.KEYCODE_5, "5", 3), GK(KeyEvent.KEYCODE_6, "6", 3),
        GK(KeyEvent.KEYCODE_7, "7", 3), GK(KeyEvent.KEYCODE_8, "8", 2), GK(KeyEvent.KEYCODE_9, "9", 1),
        GK(KeyEvent.KEYCODE_0, "0", 0)
    ),
    listOf(
        GK(KeyEvent.KEYCODE_Q, "Q", 0), GK(KeyEvent.KEYCODE_W, "W", 1), GK(KeyEvent.KEYCODE_E, "E", 2),
        GK(KeyEvent.KEYCODE_R, "R", 3), GK(KeyEvent.KEYCODE_T, "T", 3), GK(KeyEvent.KEYCODE_Y, "Y", 3),
        GK(KeyEvent.KEYCODE_U, "U", 3), GK(KeyEvent.KEYCODE_I, "I", 2), GK(KeyEvent.KEYCODE_O, "O", 1),
        GK(KeyEvent.KEYCODE_P, "P", 0), GK(KeyEvent.KEYCODE_LEFT_BRACKET, "[", 0),
        GK(KeyEvent.KEYCODE_RIGHT_BRACKET, "]", 0)
    ),
    listOf(
        GK(KeyEvent.KEYCODE_A, "A", 0), GK(KeyEvent.KEYCODE_S, "S", 1), GK(KeyEvent.KEYCODE_D, "D", 2),
        GK(KeyEvent.KEYCODE_F, "F", 3), GK(KeyEvent.KEYCODE_G, "G", 3), GK(KeyEvent.KEYCODE_H, "H", 3),
        GK(KeyEvent.KEYCODE_J, "J", 3), GK(KeyEvent.KEYCODE_K, "K", 2), GK(KeyEvent.KEYCODE_L, "L", 1),
        GK(KeyEvent.KEYCODE_SEMICOLON, ";", 0), GK(KeyEvent.KEYCODE_APOSTROPHE, "'", 0)
    ),
    listOf(
        GK(KeyEvent.KEYCODE_Z, "Z", 0), GK(KeyEvent.KEYCODE_X, "X", 1), GK(KeyEvent.KEYCODE_C, "C", 2),
        GK(KeyEvent.KEYCODE_V, "V", 3), GK(KeyEvent.KEYCODE_B, "B", 3), GK(KeyEvent.KEYCODE_N, "N", 3),
        GK(KeyEvent.KEYCODE_M, "M", 3), GK(KeyEvent.KEYCODE_COMMA, ",", 2), GK(KeyEvent.KEYCODE_PERIOD, ".", 1),
        GK(KeyEvent.KEYCODE_SLASH, "/", 0)
    ),
    listOf(GK(KeyEvent.KEYCODE_SPACE, "", 4))
)

/** The physical key that types this char on the English layout, or -1. */
private fun englishKey(c: Char): Int = when {
    c in 'a'..'z' -> KeyEvent.KEYCODE_A + (c - 'a')
    c in 'A'..'Z' -> KeyEvent.KEYCODE_A + (c - 'A')
    c in '0'..'9' -> KeyEvent.KEYCODE_0 + (c - '0')
    c == ' ' -> KeyEvent.KEYCODE_SPACE
    c == ',' -> KeyEvent.KEYCODE_COMMA
    c == '.' -> KeyEvent.KEYCODE_PERIOD
    c == ';' -> KeyEvent.KEYCODE_SEMICOLON
    c == '\'' -> KeyEvent.KEYCODE_APOSTROPHE
    c == '/' || c == '?' -> KeyEvent.KEYCODE_SLASH
    c == '[' -> KeyEvent.KEYCODE_LEFT_BRACKET
    c == ']' -> KeyEvent.KEYCODE_RIGHT_BRACKET
    else -> -1
}

/** Finger-guide keyboard for a running game. Only the key row is redrawn when the next key changes. */
@Composable
fun GuideHost(g: Game) {
    val next = remember(g, g.version) {
        val e = g.engine
        if (e.pos >= e.length) -1
        else {
            val c = e.text[e.pos]
            if (g.hindi) (Inscript.keyFor(c) ?: -1) else englishKey(c)
        }
    }
    FingerKeyboard(g.hindi, next)
}

@Composable
fun FingerKeyboard(hindi: Boolean, next: Int) {
    val compact = LocalConfiguration.current.screenHeightDp < 420
    val kw = if (compact) 28.dp else 34.dp
    val kh = if (compact) 21.dp else 27.dp
    val spaceW = if (compact) 170.dp else 200.dp
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        ROWS.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                row.forEach { k ->
                    val label = if (k.code == KeyEvent.KEYCODE_SPACE) ""
                    else if (hindi) {
                        val c = Inscript.normalChar(k.code)
                        if (c == null) k.en else keyLabel(c)
                    } else k.en
                    GuideKey(
                        label, FINGER_COLORS[k.f], k.code == next,
                        if (k.code == KeyEvent.KEYCODE_SPACE) spaceW else kw, kh
                    )
                }
            }
        }
    }
}

@Composable
private fun GuideKey(label: String, finger: Color, isNext: Boolean, w: Dp, h: Dp) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(6.dp)
    Box(
        Modifier.width(w).height(h).clip(shape)
            .background(if (isNext) p.accent else lerp(p.panel, finger, 0.28f))
            .border(1.dp, if (isNext) p.accent else p.line, shape),
        contentAlignment = Alignment.Center
    ) {
        if (label.isNotEmpty()) {
            Txt(label, 12, if (isNext) p.onAccent else p.text, if (isNext) FontWeight.Bold else FontWeight.Normal)
        }
    }
}
