package com.gkutype.app.ui

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Colour tokens, same values as the approved web preview. */
data class Pal(
    val bg: Color, val panel: Color, val line: Color, val text: Color, val dim: Color,
    val pending: Color, val accent: Color, val onAccent: Color, val bad: Color, val ok: Color,
    val dark: Boolean
)

val LightPal = Pal(
    Color(0xFFF3F1EC), Color(0xFFFFFFFF), Color(0xFFDDD8CE), Color(0xFF1D1A16), Color(0xFF6F675C),
    Color(0xFFA39B8E), Color(0xFFC77700), Color(0xFFFFFFFF), Color(0xFFC0392B), Color(0xFF2E7D4F), false
)
val DarkPal = Pal(
    Color(0xFF14120F), Color(0xFF1F1C17), Color(0xFF302B25), Color(0xFFEDE7DD), Color(0xFF9B9387),
    Color(0xFF6E675D), Color(0xFFF2A33A), Color(0xFF1A1206), Color(0xFFF07167), Color(0xFF8FD6A5), true
)

val LocalPal = staticCompositionLocalOf { LightPal }
