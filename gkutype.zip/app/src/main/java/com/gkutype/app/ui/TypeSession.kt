package com.gkutype.app.ui

import android.os.SystemClock
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.gkutype.app.data.Prefs
import com.gkutype.app.engine.Inscript
import com.gkutype.app.engine.TextGen
import com.gkutype.app.engine.TypingEngine
import java.util.Locale

/** One point of the live WPM graph (Part 3 draws it). */
class Sample(val sec: Float, val correct: Int, val keystrokes: Int, val mistakes: Int)

/** One test: the engine + clock + the few live numbers the screen shows. Only ticks once a second. */
class Game(
    val engine: TypingEngine,
    val mode: String,
    val dur: Int,
    val lang: String,
    val label: String
) {
    val hindi: Boolean get() = lang == TextGen.HI
    val totalWords: Int = if (engine.text.isEmpty()) 0 else engine.text.split(' ').size

    var version by mutableIntStateOf(0)       // bumped after every keystroke that changed text state
    var started by mutableStateOf(false)
    var finished by mutableStateOf(false)
    var timeTxt by mutableStateOf("")
    var wpmNow by mutableIntStateOf(0)
    var accNow by mutableFloatStateOf(100f)
    var errNow by mutableIntStateOf(0)

    var startMs: Long = 0L
    var elapsedMs: Long = 0L                   // final time, set by finish()
    val samples = ArrayList<Sample>()

    init { refreshStats(0L) }

    fun elapsed(): Long = when {
        !started -> 0L
        finished -> elapsedMs
        else -> SystemClock.elapsedRealtime() - startMs
    }

    fun start() {
        startMs = SystemClock.elapsedRealtime()
        started = true
    }

    fun refreshStats(el: Long) {
        timeTxt = when (mode) {
            "time" -> Math.max(0, Math.ceil(dur - el / 1000.0).toInt()).toString()
            "words" -> engine.spaces.toString() + "/" + totalWords
            else -> (el / 1000L).toString()
        }
        wpmNow = engine.wpm(el)
        accNow = engine.accuracy()
        errNow = engine.mistakes
    }

    /** Called once a second while typing. Returns true if the test ended (time up). */
    fun tick(): Boolean {
        val el = elapsed()
        if (mode == "time" && el >= dur * 1000L) {
            finish()
            return true
        }
        samples.add(Sample(el / 1000f, engine.correct, engine.keystrokes, engine.mistakes))
        refreshStats(el)
        return false
    }

    fun finish() {
        if (finished) return
        val el = SystemClock.elapsedRealtime() - startMs
        elapsedMs = if (mode == "time") Math.min(el, dur * 1000L) else el
        samples.add(Sample(elapsedMs / 1000f, engine.correct, engine.keystrokes, engine.mistakes))
        finished = true
    }
}

/** Simple result for Part 2. Part 3 replaces the placeholder screen with the real Result screen. */
class TestResult(
    val game: Game,
    val wpm: Int,
    val raw: Int,
    val accuracy: Float,
    val wrong: Int,
    val skipped: Int,
    val keystrokes: Int,
    val correct: Int,
    val seconds: Int,
    val newBest: Boolean,
    val label: String
)

fun fmt1(v: Float): String = String.format(Locale.US, "%.1f", v)

/**
 * Everything the Type screen needs, kept above the tabs so switching tabs does not lose the config.
 * Weak keys are only remembered in memory for now (Part 3 stores them on the phone).
 */
class TypeSession(private val prefs: Prefs) {
    var mode by mutableStateOf("time")
    var lang by mutableStateOf(TextGen.EN)
    var dur by mutableIntStateOf(30)
    var wc by mutableIntStateOf(25)
    var pun by mutableStateOf(false)
    var num by mutableStateOf(false)
    var weak by mutableStateOf(false)
    var customOpen by mutableStateOf(false)
    var barsVisible by mutableStateOf(true)
    var hasKeyboard by mutableStateOf(false)
    var result by mutableStateOf<TestResult?>(null)

    private val weakStore = HashMap<Char, Int>()
    private var bestWpm = 0
    private var testsDone = 0

    var game: Game by mutableStateOf(makeGame())
        private set

    /** True while a test is running (first key pressed, not finished). */
    val running: Boolean get() = game.started && !game.finished

    /** Rail and config bars are hidden while typing. */
    val barsHidden: Boolean get() = running && !barsVisible

    fun showBars() { if (!barsVisible) barsVisible = true }

    private fun weakChars(): String {
        val hindi = lang == TextGen.HI
        val top = weakStore.entries
            .filter { en -> if (hindi) en.key in '\u0900'..'\u097F' else (en.key.isLetter() && en.key.code < 128) }
            .sortedByDescending { en -> en.value }
            .take(5)
            .map { en -> en.key }
        if (top.isEmpty()) return if (hindi) "रतय" else "rty"
        return top.joinToString("")
    }

    private fun makeGame(): Game {
        val weakStr = if (weak) weakChars() else ""
        val text = TextGen.build(lang, mode, dur, wc, pun, num, weakStr)
        val size = when (mode) {
            "time" -> " $dur"
            "words" -> " $wc"
            else -> ""
        }
        val label = mode + size + " · " + lang
        return Game(TypingEngine(text), mode, dur, lang, label)
    }

    fun newGame() {
        game = makeGame()
        result = null
        barsVisible = true
    }

    /** Leaving the Type screen in the middle of a test throws that test away (same as the preview). */
    fun abandon() {
        if (game.started && !game.finished) newGame()
    }

    fun setMode(v: String) { mode = v; customOpen = false; newGame() }
    fun setLang(v: String) { lang = v; newGame() }
    fun setDur(v: Int) { dur = v; customOpen = false; newGame() }
    fun setWords(v: Int) { wc = v; customOpen = false; newGame() }
    fun togglePun() { pun = !pun; newGame() }
    fun toggleNum() { num = !num; newGame() }
    fun toggleWeak() { weak = !weak; newGame() }

    /** Test finished (text done or time up): build the result. */
    fun complete() {
        val g = game
        g.finish()
        if (result != null) return
        val e = g.engine
        val ms = g.elapsedMs
        val w = e.wpm(ms)
        val nb = testsDone > 0 && w > bestWpm && w > 0
        if (w > bestWpm) bestWpm = w
        testsDone++
        for ((c, n) in e.missCount) {
            val k = if (c.code < 128) c.lowercaseChar() else c
            weakStore[k] = (weakStore[k] ?: 0) + n
        }
        result = TestResult(
            g, w, e.rawWpm(ms), e.accuracy(), e.mistakes, e.skipped, e.keystrokes, e.correct,
            Math.round(ms / 1000.0).toInt(), nb, g.label
        )
        barsVisible = true
    }

    /** All hardware keys arrive here (from MainActivity). Returns true if the key was used. */
    fun onKey(e: KeyEvent): Boolean {
        if (e.action != KeyEvent.ACTION_DOWN) return false
        val k = e.keyCode

        if (customOpen) {
            // The number box is open: keys belong to it. Esc closes it.
            if (k == KeyEvent.KEYCODE_ESCAPE) { customOpen = false; return true }
            return false
        }
        if (e.isCtrlPressed || e.isAltPressed || e.isMetaPressed) return false

        if (result != null) {
            if (k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER ||
                k == KeyEvent.KEYCODE_TAB || k == KeyEvent.KEYCODE_ESCAPE
            ) {
                newGame()
                return true
            }
            return false
        }

        if (k == KeyEvent.KEYCODE_TAB || k == KeyEvent.KEYCODE_ESCAPE) { newGame(); return true }
        if (k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER) return true

        val g = game
        if (g.finished) return false

        if (k == KeyEvent.KEYCODE_DEL) {
            if (g.started) {
                if (g.engine.backspace()) g.version++
            }
            return true
        }

        val ch: Char? = if (g.hindi) {
            Inscript.charFor(k, e.isShiftPressed)
        } else {
            val u = e.unicodeChar
            if (u in 32..0xFFFF && u != 127) u.toChar() else null
        }
        if (ch == null) return false
        if (e.repeatCount > 0) return true // holding a key must not type again

        if (!hasKeyboard) hasKeyboard = true
        if (!g.started) g.start()
        g.engine.stopOnError = prefs.stopOnError
        if (barsVisible) barsVisible = false
        if (g.engine.type(ch)) g.version++
        if (g.engine.done) complete()
        return true
    }
}
