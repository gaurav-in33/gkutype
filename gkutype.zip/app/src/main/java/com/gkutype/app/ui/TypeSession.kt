package com.gkutype.app.ui

import android.os.SystemClock
import android.view.KeyCharacterMap
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.gkutype.app.data.LessonStore
import com.gkutype.app.data.Prefs
import com.gkutype.app.data.StatsStore
import com.gkutype.app.engine.Inscript
import com.gkutype.app.engine.Lessons
import com.gkutype.app.engine.TextGen
import com.gkutype.app.engine.TypingEngine
import java.util.Locale

/** One point of the WPM graph (the Result screen draws it). */
class Sample(val sec: Float, val correct: Int, val keystrokes: Int, val mistakes: Int)

/** One test: the engine + clock + the few live numbers the screen shows. Only ticks once a second. */
class Game(
    val engine: TypingEngine,
    val mode: String,
    val dur: Int,
    val lang: String,
    val label: String
) {
    val hindi: Boolean get() = lang == TextGen.HI
    val totalWords: Int = if (engine.text.isEmpty()) 0 else engine.text.split(' ').size

    var version by mutableIntStateOf(0)       // bumped after every keystroke that changed text state
    var started by mutableStateOf(false)
    var finished by mutableStateOf(false)
    var timeTxt by mutableStateOf("")
    var wpmNow by mutableIntStateOf(0)
    var accNow by mutableFloatStateOf(100f)
    var errNow by mutableIntStateOf(0)

    var startMs: Long = 0L
    var elapsedMs: Long = 0L                   // final time, set by finish()
    val samples = ArrayList<Sample>()

    init { refreshStats(0L) }

    fun elapsed(): Long = when {
        !started -> 0L
        finished -> elapsedMs
        else -> SystemClock.elapsedRealtime() - startMs
    }

    fun start() {
        startMs = SystemClock.elapsedRealtime()
        started = true
    }

    fun refreshStats(el: Long) {
        timeTxt = when (mode) {
            "time" -> Math.max(0, Math.ceil(dur - el / 1000.0).toInt()).toString()
            "words" -> engine.spaces.toString() + "/" + totalWords
            else -> (el / 1000L).toString()
        }
        wpmNow = engine.wpm(el)
        accNow = engine.accuracy()
        errNow = engine.mistakes
    }

    /** Called once a second while typing. Returns true if the test ended (time up). */
    fun tick(): Boolean {
        val el = elapsed()
        if (mode == "time" && el >= dur * 1000L) {
            finish()
            return true
        }
        samples.add(Sample(el / 1000f, engine.correct, engine.keystrokes, engine.mistakes))
        refreshStats(el)
        return false
    }

    fun finish() {
        if (finished) return
        val el = SystemClock.elapsedRealtime() - startMs
        elapsedMs = if (mode == "time") Math.min(el, dur * 1000L) else el
        samples.add(Sample(elapsedMs / 1000f, engine.correct, engine.keystrokes, engine.mistakes))
        finished = true
    }
}

/** Everything the Result screen shows. */
class TestResult(
    val game: Game,
    val wpm: Int,
    val raw: Int,
    val accuracy: Float,
    val wrong: Int,
    val skipped: Int,
    val keystrokes: Int,
    val correct: Int,
    val seconds: Int,
    val newBest: Boolean,
    val label: String,
    val target: Int = 0,          // lesson accuracy target in % (0 = normal test)
    val targetMet: Boolean = false
)

/** Which Learn level is running (track "en" or "hi", level index from 0). */
class LessonRef(val track: String, val idx: Int) {
    val key: String get() = track + ":" + idx
}

fun fmt1(v: Float): String = String.format(Locale.US, "%.1f", v)

/**
 * Everything the Type screen needs, kept above the tabs so switching tabs does not lose the config.
 * Finished tests are saved to [StatsStore] (once, when the test ends).
 */
class TypeSession(private val prefs: Prefs, private val store: StatsStore, private val lessons: LessonStore) {
    var mode by mutableStateOf("time")
    var lang by mutableStateOf(TextGen.EN)
    var dur by mutableIntStateOf(30)
    var wc by mutableIntStateOf(25)
    var pun by mutableStateOf(false)
    var num by mutableStateOf(false)
    var weak by mutableStateOf(false)
    var customOpen by mutableStateOf(false)
    var barsVisible by mutableStateOf(true)
    var hasKeyboard by mutableStateOf(false)
    var result by mutableStateOf<TestResult?>(null)

    /** Non-null while a Learn level is running (fixed 60 s, no config bar). */
    var lesson by mutableStateOf<LessonRef?>(null)
        private set

    /** Set by the app shell: switch to the Learn tab. */
    var onLeaveLesson: (() -> Unit)? = null

    var game: Game by mutableStateOf(makeGame())
        private set

    /** True while a test is running (first key pressed, not finished). */
    val running: Boolean get() = game.started && !game.finished

    /** Rail and config bars are hidden while typing. */
    val barsHidden: Boolean get() = running && !barsVisible

    fun showBars() { if (!barsVisible) barsVisible = true }

    private fun weakChars(): String {
        val hindi = lang == TextGen.HI
        val top = store.misses.entries
            .filter { en -> if (hindi) en.key in '\u0900'..'\u097F' else (en.key.isLetter() && en.key.code < 128) }
            .sortedByDescending { en -> en.value }
            .take(5)
            .map { en -> en.key }
        if (top.isEmpty()) return if (hindi) "रतय" else "rty"
        return top.joinToString("")
    }

    private fun makeGame(): Game {
        val weakStr = if (weak) weakChars() else ""
        val text = TextGen.build(lang, mode, dur, wc, pun, num, weakStr)
        val size = when (mode) {
            "time" -> " $dur"
            "words" -> " $wc"
            else -> ""
        }
        val label = mode + size + " · " + lang
        return Game(TypingEngine(text), mode, dur, lang, label)
    }

    private fun lessonGame(l: LessonRef): Game {
        val d = Lessons.defs(l.track)[l.idx]
        val hi = l.track == Lessons.HI
        val label = Lessons.name(l.track) + " · level " + (l.idx + 1)
        return Game(TypingEngine(d.make()), "time", 60, if (hi) TextGen.HI else TextGen.EN, label)
    }

    fun startLesson(track: String, idx: Int) {
        val l = LessonRef(track, idx)
        lesson = l
        lessons.setLast(l.key)
        newGame()
    }

    /** Back to normal tests (Type tab). */
    fun exitLesson() {
        if (lesson != null) {
            lesson = null
            newGame()
        }
    }

    /** From the lesson result: go back to the Learn list. */
    fun leaveLesson() {
        lesson = null
        newGame()
        onLeaveLesson?.invoke()
    }

    fun newGame() {
        val l = lesson
        game = if (l != null) lessonGame(l) else makeGame()
        result = null
        barsVisible = true
    }

    /** Leaving the Type screen in the middle of a test throws that test away (same as the preview). */
    fun abandon() {
        if (game.started && !game.finished) newGame()
    }

    fun changeMode(v: String) { mode = v; customOpen = false; newGame() }
    fun changeLang(v: String) { lang = v; newGame() }
    fun changeDur(v: Int) { dur = v; customOpen = false; newGame() }
    fun changeWords(v: Int) { wc = v; customOpen = false; newGame() }
    fun togglePun() { pun = !pun; newGame() }
    fun toggleNum() { num = !num; newGame() }
    fun toggleWeak() { weak = !weak; newGame() }

    /** Test finished (text done or time up): build the result. */
    fun complete() {
        val g = game
        g.finish()
        if (result != null) return
        val e = g.engine
        val ms = g.elapsedMs
        val w = e.wpm(ms)
        val nb = store.tests > 0 && w > store.bestWpm && w > 0
        store.record(w, e.accuracy(), e.mistakes, e.keystrokes, e.missCount)
        val l = lesson
        var target = 0
        var met = false
        if (l != null) {
            target = Lessons.defs(l.track)[l.idx].target
            if (e.keystrokes >= StatsStore.MIN_KEYS_FOR_ACC) {
                lessons.record(l.key, e.accuracy())
                met = e.accuracy() >= target
            }
        }
        result = TestResult(
            g, w, e.rawWpm(ms), e.accuracy(), e.mistakes, e.skipped, e.keystrokes, e.correct,
            Math.round(ms / 1000.0).toInt(), nb, g.label, target, met
        )
        barsVisible = true
    }

    /** All hardware keys arrive here (from MainActivity). Returns true if the key was used. */
    fun onKey(e: KeyEvent): Boolean {
        if (e.action != KeyEvent.ACTION_DOWN) return false
        val k = e.keyCode

        if (customOpen) {
            // The number box is open: keys belong to it. Esc closes it.
            if (k == KeyEvent.KEYCODE_ESCAPE) { customOpen = false; return true }
            return false
        }
        if (e.isCtrlPressed || e.isAltPressed || e.isMetaPressed) return false

        if (result != null) {
            if (k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER || k == KeyEvent.KEYCODE_TAB) {
                newGame()
                return true
            }
            if (k == KeyEvent.KEYCODE_ESCAPE) {
                if (lesson != null) leaveLesson() else newGame()
                return true
            }
            return false
        }

        if (k == KeyEvent.KEYCODE_TAB || k == KeyEvent.KEYCODE_ESCAPE) { newGame(); return true }
        if (k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER) return true

        val g = game
        if (g.finished) return false

        if (k == KeyEvent.KEYCODE_DEL) {
            if (g.started) {
                if (g.engine.backspace()) g.version++
            }
            return true
        }

        val ch: Char? = if (g.hindi) {
            Inscript.charFor(k, e.isShiftPressed)
        } else {
            // Use the physical key (US QWERTY) so a different system keyboard layout can't make
            // correct typing count as wrong. Caps Lock still gives capital letters (ABCD). Keys we don't know (numpad etc.) fall back to unicodeChar.
            val us = usChar(k, e.isShiftPressed, e.isCapsLockOn)
            if (us != null) us else {
                val u = e.unicodeChar and KeyCharacterMap.COMBINING_ACCENT_MASK.inv()
                if (u in 32..0xFFFF && u != 127) u.toChar() else null
            }
        }
        if (ch == null) return false
        if (e.repeatCount > 0) return true // holding a key must not type again

        if (!hasKeyboard) hasKeyboard = true
        if (!g.started) g.start()
        g.engine.stopOnError = prefs.stopOnError
        if (barsVisible) barsVisible = false
        if (g.engine.type(ch)) g.version++
        if (g.engine.done) complete()
        return true
    }
}

private fun usChar(k: Int, shift: Boolean, caps: Boolean): Char? {
    if (k in KeyEvent.KEYCODE_A..KeyEvent.KEYCODE_Z) {
        val c = 'a' + (k - KeyEvent.KEYCODE_A)
        return if (shift != caps) c.uppercaseChar() else c
    }
    if (k in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9) {
        val i = k - KeyEvent.KEYCODE_0
        return if (shift) ")!@#\$%^&*("[i] else '0' + i
    }
    return when (k) {
        KeyEvent.KEYCODE_SPACE -> ' '
        KeyEvent.KEYCODE_MINUS -> if (shift) '_' else '-'
        KeyEvent.KEYCODE_EQUALS -> if (shift) '+' else '='
        KeyEvent.KEYCODE_LEFT_BRACKET -> if (shift) '{' else '['
        KeyEvent.KEYCODE_RIGHT_BRACKET -> if (shift) '}' else ']'
        KeyEvent.KEYCODE_BACKSLASH -> if (shift) '|' else '\\'
        KeyEvent.KEYCODE_SEMICOLON -> if (shift) ':' else ';'
        KeyEvent.KEYCODE_APOSTROPHE -> if (shift) '"' else '\''
        KeyEvent.KEYCODE_COMMA -> if (shift) '<' else ','
        KeyEvent.KEYCODE_PERIOD -> if (shift) '>' else '.'
        KeyEvent.KEYCODE_SLASH -> if (shift) '?' else '/'
        KeyEvent.KEYCODE_GRAVE -> if (shift) '~' else '`'
        else -> null
    }
}
