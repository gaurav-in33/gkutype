package com.gkutype.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Settings only. Stored locally in SharedPreferences, written when a setting changes. */
class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("gku_settings", Context.MODE_PRIVATE)

    var theme by mutableStateOf(p.getString("theme", "light") ?: "light")
        private set
    var textSize by mutableIntStateOf(p.getInt("size", 26))
        private set
    var guide by mutableStateOf(p.getString("guide", "lessons") ?: "lessons")
        private set
    var cursor by mutableStateOf(p.getString("cursor", "block") ?: "block")
        private set
    var stopOnError by mutableStateOf(p.getBoolean("stop", false))
        private set
    var lowMotion by mutableStateOf(p.getBoolean("low", false))
        private set

    fun changeTheme(v: String) { theme = v; p.edit().putString("theme", v).apply() }
    fun changeTextSize(v: Int) { textSize = v; p.edit().putInt("size", v).apply() }
    fun changeGuide(v: String) { guide = v; p.edit().putString("guide", v).apply() }
    fun changeCursor(v: String) { cursor = v; p.edit().putString("cursor", v).apply() }
    fun changeStopOnError(v: Boolean) { stopOnError = v; p.edit().putBoolean("stop", v).apply() }
    fun changeLowMotion(v: Boolean) { lowMotion = v; p.edit().putBoolean("low", v).apply() }
}
