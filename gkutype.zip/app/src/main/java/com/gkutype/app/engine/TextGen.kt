package com.gkutype.app.engine

import kotlin.random.Random

/** Builds the practice text for a test (same rules as preview build()). */
object TextGen {
    const val EN = "english"
    const val HI = "hindi"
    const val HG = "hinglish"

    private val devanagariDigits = "०१२३४५६७८९"

    fun wordList(lang: String): List<String> = when (lang) {
        HI -> Words.hindi
        HG -> Words.hinglish
        else -> Words.english
    }

    fun quote(lang: String, r: Random = Random.Default): String {
        val q = when (lang) {
            HI -> Words.quotesHindi
            HG -> Words.quotesHinglish
            else -> Words.quotesEnglish
        }
        return q[r.nextInt(q.size)]
    }

    /** Number of words to generate: time mode makes plenty so even a very fast typist never runs out. */
    fun wordCount(mode: String, dur: Int, wc: Int): Int =
        if (mode == "words") wc else maxOf(60, Math.ceil(dur * 3.5).toInt())

    /**
     * @param weakChars if not empty, only words containing one of these chars are used (when there are enough of them).
     */
    fun build(
        lang: String, mode: String, dur: Int, wc: Int,
        punctuation: Boolean, numbers: Boolean, weakChars: String,
        r: Random = Random.Default
    ): String {
        if (mode == "quote") return quote(lang, r)
        val hindi = lang == HI
        var list = wordList(lang)
        if (weakChars.isNotEmpty()) {
            val f = list.filter { w -> w.any { ch -> weakChars.indexOf(ch) >= 0 } }
            if (f.size >= 10) list = f
        }
        val n = wordCount(mode, dur, wc)
        val sb = StringBuilder()
        var cap = !hindi
        var prev = ""
        for (i in 0 until n) {
            var w = list[r.nextInt(list.size)]
            if (list.size > 1) {
                while (w == prev) w = list[r.nextInt(list.size)]
            }
            prev = w
            if (numbers && r.nextDouble() < 0.15) {
                w = (1 + r.nextInt(999)).toString()
                if (hindi) w = w.map { d -> devanagariDigits[d - '0'] }.joinToString("")
            }
            if (punctuation) {
                if (cap) {
                    w = w.substring(0, 1).uppercase() + w.substring(1)
                    cap = false
                }
                val x = r.nextDouble()
                if (x < 0.12) {
                    w += ","
                } else if (x < 0.20) {
                    w += if (hindi) "।" else "."
                    cap = !hindi
                } else if (x < 0.23 && !hindi) {
                    w += "?"
                    cap = true
                }
            }
            if (i > 0) sb.append(' ')
            sb.append(w)
        }
        return sb.toString()
    }
}
