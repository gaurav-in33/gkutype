package com.gkutype.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp

/** The final Gku Type logo: cream tile, "Gku" black, "Type" amber, three keycaps. Uses the same paths as the app icon. */
@Composable
fun GkuLogo(size: Dp, modifier: Modifier = Modifier) {
    val paths = remember {
        listOf(LogoPaths.GKU, LogoPaths.TYPE, LogoPaths.KEY_L, LogoPaths.KEY_M, LogoPaths.KEY_R)
            .map { PathParser().parsePathString(it).toPath() }
    }
    val tile = Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFFAEEDB)))
    val amber = Brush.verticalGradient(listOf(Color(0xFFFFA92E), Color(0xFFF08A0C)))
    val ink = Color(0xFF14120F)
    val key = Color(0xFF1E1B17)
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val k = s / 84f
        drawRoundRect(tile, size = Size(s, s), cornerRadius = CornerRadius(20f * k))
        drawRoundRect(
            Color(0xFFE9D9BC), topLeft = Offset(0.5f * k, 0.5f * k),
            size = Size(s - k, s - k), cornerRadius = CornerRadius(19.5f * k), style = Stroke(k)
        )
        withTransform({
            scale(k, k, Offset.Zero)
            translate(-12f, -12f)
        }) {
            val bold = Stroke(width = 0.9f, join = StrokeJoin.Round)
            drawPath(paths[0], ink)
            drawPath(paths[0], ink, style = bold)
            drawPath(paths[1], amber)
            drawPath(paths[1], Color(0xFFF59A1B), style = bold)
            drawPath(paths[2], key)
            drawPath(paths[3], amber)
            drawPath(paths[4], key)
        }
    }
}
