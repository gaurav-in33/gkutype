package com.gkutype.app.engine

import android.view.KeyEvent

/**
 * MainActivity.dispatchKeyEvent sends every hardware key here first, so Tab/Esc/Backspace and letters
 * work without any focus tricks. Return true from the handler to consume the key.
 */
object KeyRouter {
    var handler: ((KeyEvent) -> Boolean)? = null
}
