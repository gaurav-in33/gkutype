package com.gkutype.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.BasicText
import com.gkutype.app.data.Prefs

/** Phone turn: 0-25% upright, 25-55% turns sideways, 55-85% holds, 85-100% back. */
private fun turnDeg(t: Float): Float = when {
    t < 0.25f -> 0f
    t < 0.55f -> -90f * ((t - 0.25f) / 0.30f)
    t < 0.85f -> -90f
    else -> -90f * (1f - (t - 0.85f) / 0.15f)
}

private fun typeAlpha(t: Float): Float = when {
    t < 0.5f -> 0f
    t < 0.6f -> (t - 0.5f) / 0.1f
    t < 0.85f -> 1f
    else -> 1f - (t - 0.85f) / 0.15f
}

/** Portrait screen. Light Compose animation; it only runs in portrait and stops when Low motion is on. */
@Composable
fun RotateScreen(prefs: Prefs) {
    val p = LocalPal.current
    val still = prefs.lowMotion
    val t: State<Float>? = if (still) null else {
        rememberInfiniteTransition(label = "rot").animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart),
            label = "turn"
        )
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        GkuLogo(84.dp)
        Spacer(Modifier.height(16.dp))
        Txt("Rotate your phone", 28, p.text, FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        Txt("Gku Type works in landscape mode", 14, p.dim)
        Spacer(Modifier.height(18.dp))

        Box(Modifier.size(width = 150.dp, height = 96.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(width = 44.dp, height = 78.dp)
                    .graphicsLayer { rotationZ = if (t == null) 0f else turnDeg(t.value) }
                    .border(4.dp, p.text, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.BottomCenter
            ) {
                Box(
                    Modifier.padding(bottom = 4.dp).size(width = 12.dp, height = 3.dp)
                        .clip(RoundedCornerShape(2.dp)).background(p.accent)
                )
            }
            BasicText(
                "type_",
                modifier = Modifier.graphicsLayer { alpha = if (t == null) 0f else typeAlpha(t.value) },
                style = TextStyle(color = p.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            )
        }
        Spacer(Modifier.height(18.dp))

        Column(Modifier.widthIn(max = 360.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            listOf(
                "Turn on Auto-rotate in Quick Settings",
                "Turn your phone sideways",
                "Connect your USB keyboard (OTG)"
            ).forEachIndexed { i, s ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.panel)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(26.dp).clip(RoundedCornerShape(8.dp))
                            .background(Brush.verticalGradient(listOf(Color(0xFFFFA92E), Color(0xFFF08A0C)))),
                        contentAlignment = Alignment.Center
                    ) { Txt("${i + 1}", 13, Color(0xFF1A1206), FontWeight.Bold) }
                    Txt(s, 13, p.text)
                }
            }
        }
    }
}
