package com.gkutype.app.ui

import android.content.res.Configuration
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gkutype.app.data.Prefs

enum class Tab(val label: String) { Type("Type"), Learn("Learn"), Stats("Stats"), Settings("Settings") }

@Composable
fun GkuApp(prefs: Prefs) {
    val pal = if (prefs.theme == "dark") DarkPal else LightPal
    val session = remember { TypeSession(prefs) }
    CompositionLocalProvider(LocalPal provides pal) {
        val portrait = LocalConfiguration.current.orientation == Configuration.ORIENTATION_PORTRAIT
        Box(
            Modifier.fillMaxSize().background(pal.bg).windowInsetsPadding(WindowInsets.displayCutout)
        ) {
            if (portrait) RotateScreen() else Shell(prefs, session)
        }
    }
}

@Composable
private fun Shell(prefs: Prefs, session: TypeSession) {
    var tab by remember { mutableStateOf(Tab.Type) }
    val p = LocalPal.current
    val onType = tab == Tab.Type
    val showRail = !(onType && session.result != null)
    val hide = onType && session.barsHidden
    val spec: AnimationSpec<Float> = if (prefs.lowMotion) snap() else tween(250)
    val a by animateFloatAsState(targetValue = if (hide) 0f else 1f, animationSpec = spec, label = "rail")
    Row(
        Modifier.fillMaxSize().pointerInput(Unit) {
            // Any touch brings the rail and menus back (they hide while typing).
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                session.showBars()
            }
        }
    ) {
        if (showRail) {
            Box(Modifier.fillMaxHeight().alpha(a)) { Rail(tab, !hide) { tab = it } }
            Box(Modifier.width(1.dp).fillMaxHeight().background(p.line).alpha(a))
        }
        Box(Modifier.weight(1f).fillMaxHeight()) {
            when (tab) {
                Tab.Type -> TypeScreen(session, prefs)
                Tab.Learn -> Placeholder("Learn", "Course arrives in Part 4")
                Tab.Stats -> Placeholder("Stats", "Stats arrive in Part 3")
                Tab.Settings -> SettingsScreen(prefs)
            }
        }
    }
}

@Composable
private fun Rail(tab: Tab, enabled: Boolean, onTab: (Tab) -> Unit) {
    val p = LocalPal.current
    Column(
        Modifier.width(88.dp).fillMaxHeight().padding(horizontal = 8.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(Modifier.padding(start = 8.dp, bottom = 10.dp)) { GkuLogo(46.dp) }
        Tab.values().forEach { t ->
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(9.dp))
                    .background(if (t == tab) p.panel else Color.Transparent)
                    .clickable(enabled = enabled) { onTab(t) }
                    .padding(horizontal = 10.dp, vertical = 9.dp)
            ) { Txt(t.label, 14, if (t == tab) p.text else p.dim) }
        }
    }
}

@Composable
private fun Placeholder(title: String, note: String) {
    val p = LocalPal.current
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Txt(title, 26, p.text, FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Txt(note, 14, p.dim)
    }
}

/** Part 1 settings: theme only (storage for all settings already exists in Prefs). Full screen comes in Part 5. */
@Composable
private fun SettingsScreen(prefs: Prefs) {
    val p = LocalPal.current
    Column(Modifier.fillMaxSize().padding(26.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Txt("Settings", 20, p.text, FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Txt("Theme", 15, p.dim, modifier = Modifier.width(90.dp))
            Chip("light", prefs.theme == "light") { prefs.changeTheme("light") }
            Chip("dark", prefs.theme == "dark") { prefs.changeTheme("dark") }
        }
        Txt("More settings arrive in Part 5.", 13, p.dim)
    }
}

/** Portrait screen. Static for now; the turning-phone animation comes in Part 5. */
@Composable
private fun RotateScreen() {
    val p = LocalPal.current
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        GkuLogo(84.dp)
        Spacer(Modifier.height(18.dp))
        Txt("Rotate your phone", 24, p.text, FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Txt("Gku Type works in landscape mode", 14, p.dim)
        Spacer(Modifier.height(22.dp))
        listOf(
            "Turn on Auto-rotate in Quick Settings",
            "Turn your phone sideways",
            "Connect your USB keyboard (OTG)"
        ).forEachIndexed { i, s ->
            Row(
                Modifier.fillMaxWidth().padding(vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(p.accent).width(24.dp).height(24.dp),
                    contentAlignment = Alignment.Center
                ) { Txt("${i + 1}", 13, p.onAccent, FontWeight.SemiBold) }
                Txt(s, 14, p.text)
            }
        }
    }
}
