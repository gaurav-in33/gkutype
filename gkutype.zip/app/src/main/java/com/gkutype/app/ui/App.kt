package com.gkutype.app.ui

import android.app.Activity
import android.content.res.Configuration
import android.graphics.drawable.ColorDrawable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.gkutype.app.data.LessonStore
import com.gkutype.app.data.Prefs
import com.gkutype.app.data.StatsStore

enum class Tab(val label: String) { Type("Type"), Learn("Learn"), Stats("Stats"), Settings("Settings") }

@Composable
fun GkuApp(prefs: Prefs) {
    val pal = if (prefs.theme == "dark") DarkPal else LightPal
    val ctx = LocalContext.current
    val store = remember { StatsStore(ctx.applicationContext) }
    val lessons = remember { LessonStore(ctx.applicationContext) }
    val session = remember { TypeSession(prefs, store, lessons) }
    val act = ctx as? Activity
    SideEffect { act?.window?.setBackgroundDrawable(ColorDrawable(pal.bg.toArgb())) }
    CompositionLocalProvider(LocalPal provides pal) {
        val portrait = LocalConfiguration.current.orientation == Configuration.ORIENTATION_PORTRAIT
        Box(
            Modifier.fillMaxSize().background(pal.bg).windowInsetsPadding(WindowInsets.displayCutout)
        ) {
            if (portrait) RotateScreen(prefs) else Shell(prefs, session, store, lessons)
        }
    }
}

@Composable
private fun Shell(prefs: Prefs, session: TypeSession, store: StatsStore, lessons: LessonStore) {
    var tab by remember { mutableStateOf(Tab.Type) }
    DisposableEffect(session) {
        session.onLeaveLesson = { tab = Tab.Learn }
        onDispose { session.onLeaveLesson = null }
    }
    val p = LocalPal.current
    val onType = tab == Tab.Type
    val showRail = !(onType && session.result != null)
    val hide = onType && session.barsHidden
    val spec: AnimationSpec<Float> = if (prefs.lowMotion) snap() else tween(250)
    val a by animateFloatAsState(targetValue = if (hide) 0f else 1f, animationSpec = spec, label = "rail")
    Row(
        Modifier.fillMaxSize().pointerInput(Unit) {
            // Any touch brings the rail and menus back (they hide while typing).
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                session.showBars()
            }
        }
    ) {
        if (showRail) {
            Box(Modifier.fillMaxHeight().alpha(a)) { Rail(tab, !hide) { t ->
                    if (t == Tab.Type) session.exitLesson()
                    tab = t
                } }
            Box(Modifier.width(1.dp).fillMaxHeight().background(p.line).alpha(a))
        }
        Box(Modifier.weight(1f).fillMaxHeight()) {
            when (tab) {
                Tab.Type -> TypeScreen(session, prefs)
                Tab.Learn -> LearnScreen(lessons) { track, idx ->
                    session.startLesson(track, idx)
                    tab = Tab.Type
                }
                Tab.Stats -> StatsScreen(store)
                Tab.Settings -> SettingsScreen(prefs)
            }
        }
    }
}

@Composable
private fun Rail(tab: Tab, enabled: Boolean, onTab: (Tab) -> Unit) {
    val p = LocalPal.current
    Column(
        Modifier.width(88.dp).fillMaxHeight().padding(horizontal = 8.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(Modifier.padding(start = 8.dp, bottom = 10.dp)) { GkuLogo(46.dp) }
        Tab.values().forEach { t ->
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(9.dp))
                    .background(if (t == tab) p.panel else Color.Transparent)
                    .clickable(enabled = enabled) { onTab(t) }
                    .padding(horizontal = 10.dp, vertical = 9.dp)
            ) {
                val c = if (t == tab) p.text else p.dim
                if (t == Tab.Settings) GearIcon(c) else Txt(t.label, 14, c)
            }
        }
    }
}

@Composable
private fun GearIcon(color: Color) {
    androidx.compose.foundation.Canvas(Modifier.width(22.dp).height(22.dp)) {
        val c = androidx.compose.ui.geometry.Offset(size.width / 2, size.height / 2)
        val r = size.minDimension / 2
        drawCircle(color, r * 0.62f, c, style = androidx.compose.ui.graphics.drawscope.Stroke(width = r * 0.28f))
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0)
            val dx = Math.cos(a).toFloat()
            val dy = Math.sin(a).toFloat()
            drawLine(
                color,
                androidx.compose.ui.geometry.Offset(c.x + dx * r * 0.7f, c.y + dy * r * 0.7f),
                androidx.compose.ui.geometry.Offset(c.x + dx * r * 0.98f, c.y + dy * r * 0.98f),
                strokeWidth = r * 0.3f
            )
        }
    }
}
