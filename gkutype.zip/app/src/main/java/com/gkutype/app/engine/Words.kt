package com.gkutype.app.engine

/**
 * Offline word lists and quotes. Hindi words use only letters that can be typed on the Inscript layout.
 * Words are stored as plain text blocks (split on whitespace) so the file stays small.
 */
object Words {
    private fun split(s: String): List<String> = s.split(' ', '\n').filter { it.isNotEmpty() }

    val english: List<String> = split("""
the of and to in is that it for on are as
with his they at be this from have or by one had
not but what all were when we there can an your which
their said if do will each about how up out them then
she many some so these would other into has more her two
like him see time could no make than first been its who
now people my made over did down only way find use may
water long little very after words called just where most know get
through back much before go good new write our used me man
too any day same right look think also around another came come
work three word must because does part even place well such here
take why things help put years different away again off went old
number great tell men say small every found still between name should
home big give air line set own under read last never us
left end along while might next sound below saw something thought both
few those always show large often together asked house world going want
school important until form food keep children feet land side without boy
once animal life enough took sometimes four head above kind began almost
live page got earth need far hand high year mother light country
father let night picture being study second soon story since white ever
paper hard near sentence better best across during today however sure knew
try told young sun thing whole hear example heard several change answer
room sea against top turned learn point city play toward five using
himself usually money seen car morning body upon family later turn move
face door cut done group true leave color red friend pretty fast
pay type girl plan table ground reach build watch week month season
summer winter spring autumn weather rain snow wind cloud storm river lake
mountain forest garden flower grass tree stone road street bridge village town
island ocean beach desert field farm market shop store bank office hospital
station airport train bus plane boat ship bicycle truck ticket journey travel
visit trip guide map compass camera phone screen keyboard mouse laptop computer
internet email message letter book pencil pen notebook library teacher student lesson
class exam test grade subject science math history language music art dance
song drama movie painting paint brush blue green yellow orange purple pink
brown black gray silver golden bright dark heavy soft smooth rough sharp
quiet loud strong weak quick slow early late fresh clean dirty empty
full open close simple easy difficult ready busy free safe happy sad
angry calm brave proud gentle honest polite lucky careful curious clever smart
wise foolish funny serious strange special common rare famous popular modern ancient
natural magic secret silent hidden broken perfect fair equal single double half
piece team member leader player winner game sport race ball goal score
match coach training practice habit skill talent effort energy power speed focus
memory mind idea dream hope wish fear doubt trust respect honor duty
freedom peace war law rule order choice chance risk reward price cost
value profit income budget saving trade business company worker boss job career
project result success failure mistake progress growth future past present moment minute
hour noon evening midnight yesterday tomorrow daily weekly monthly yearly breakfast lunch
dinner bread butter cheese milk rice meat fish egg fruit apple banana
grape lemon cherry tomato potato onion carrot salad soup sugar salt pepper
coffee juice cake cookie candy kitchen bottle bowl plate spoon knife fork
glass cup basket bag box pocket wallet coin key lock window wall
floor roof ceiling stairs bed chair desk lamp mirror clock towel soap
blanket pillow shirt pants dress jacket coat hat shoe sock glove scarf
button zipper
""")

    val hinglish: List<String> = split("""
mera tera uska hamara tumhara aapka apna hum tum aap main woh
yeh kya kaun kab kahan kaise kyun kitna kitni kitne kuch koi
sab sabhi har ek do teen char paanch chhe saat aath nau
das bees tees chalis pachas sau hazar lakh karod pehla doosra teesra
aakhri naya purana accha bura bada chhota lamba mota patla sundar saaf
ganda tez dheere jaldi der abhi phir kabhi hamesha kam zyada bahut
thoda poora aadha sahi galat sach jhooth aasan mushkil khush udaas gussa
dar himmat pyaar dosti nafrat sharam izzat ghar kamra darwaza khidki chhat
deewar farsh rasoi bistar kursi mez almari sheesha ghadi kitab kapda kapde
kameez pant jooti topi chashma thaila paisa rupaya note sikka dukaan bazaar
mandir masjid school college office station sadak rasta pul gali mohalla shehar
gaon desh duniya zameen aasman suraj chand tara baadal baarish dhoop chhaon
hawa aandhi toofan sardi garmi mausam nadi talab samundar pahad jungle ped
paudha phool patta ghaas mitti pathar ret aag pani doodh dahi ghee
makhan cheeni namak mirch chai roti chawal dal sabzi aloo pyaaz tamatar
gajar matar gobhi bhindi baingan nimbu aam kela seb santra angoor anar
papita tarbooz amrood khana peena sona uthna baithna chalna daudna bolna sunna
dekhna padhna likhna seekhna sikhana samajhna jaanna maanna poochna batana dena lena
rakhna kholna band karna jaana aana hona rehna milna bulana bhejna bhoolna
yaad sochna chahna dhoondhna banana todna jodna kaatna kheenchna dhakelna girna uthana
bachana jeetna haarna khelna hasna rona gaana nachna tairna udna chadhna utarna
pakadna chhodna dhona sukhana pakana jalana bujhana jagana sulana dikhana sunana padhana
likhana maangna chukana kamana kharidna bechna ginna naapna tolna bharna khaali kaam
kaaj naukri vyapaar mehnat tankhwah chhutti samay waqt ghanta minute pal din
raat subah dopahar shaam kal aaj parson hafta mahina saal somwar mangalwar
budhwar guruwar shukrawar shaniwar raviwar maa papa bhai behen dada dadi nana
nani chacha chachi mama mami beta beti pati patni dost saathi padosi
guru shikshak vidyarthi doctor vakeel kisan mazdoor driver dukandar naam umar pata
number phone mobile call message photo video khel film kahani kavita geet
sangeet naach rang laal peela neela hara kaala safed gulabi bhura sir
baal aankh kaan naak munh daant zubaan gala kandha haath ungli pet
peeth pair ghutna dil dimaag khoon haddi chehra sehat bimari dawai dard
aaram neend sapna hamare tumhare unka iska kisi kisko kisne isliye lekin
magar aur ya toh bhi hi na nahi mat zaroor shayad bilkul
sirf bas wahi yahi yahan wahan upar neeche andar bahar aage peeche
paas door saath bina ke liye se tak mein par ko ne
ka ki hai hain tha thi the hoga hogi honge kar karo
karta karti karte kiya kiye gaya gayi gaye aaya aayi aaye jao
aao chalo ruko dekho suno bolo batao pucho likho padho seekho khao
piyo socho samjho dhyan lagao koshish roz practice badho galti behtar bano
speed accuracy typing keyboard screen text word line sentence paragraph lesson level
test result score best average progress goal target focus rhythm posture fingers
home row top bottom shift space enter backspace tab
""")

    val hindi: List<String> = split("""
में है हैं था थी थे को से पर का की के
और या भी तो ही नहीं हाँ जी अब जब तब कब
कहाँ यहाँ वहाँ कैसे कैसा कैसी क्यों क्या कौन कोई कुछ सब
सभी हर एक दो तीन चार पाँच छह सात आठ नौ दस
बीस तीस चालीस पचास सौ हजार लाख पहला दूसरा तीसरा आखिरी नया
पुराना अच्छा बुरा बड़ा छोटा लंबा मोटा पतला सुंदर साफ गंदा तेज
धीरे जल्दी देर अभी फिर कभी हमेशा कम ज्यादा बहुत थोड़ा पूरा
आधा सही गलत सच झूठ आसान मुश्किल खुश उदास गुस्सा डर हिम्मत
प्यार दोस्ती नफरत शर्म इज्जत घर कमरा दरवाजा खिड़की छत दीवार फर्श
रसोई बिस्तर कुर्सी मेज अलमारी शीशा घड़ी किताब कपड़ा कमीज पैंट जूता
टोपी चश्मा थैला पैसा रुपया सिक्का दुकान बाजार मंदिर मस्जिद स्कूल दफ्तर
स्टेशन सड़क रास्ता पुल गली मोहल्ला शहर गाँव देश दुनिया जमीन आसमान
सूरज चाँद तारा बादल बारिश धूप छाँव हवा आँधी तूफान सर्दी गर्मी
मौसम नदी तालाब समुद्र पहाड़ जंगल पेड़ पौधा फूल पत्ता घास मिट्टी
पत्थर रेत आग पानी दूध दही घी मक्खन चीनी नमक मिर्च चाय
रोटी चावल दाल सब्जी आलू प्याज टमाटर गाजर मटर गोभी भिंडी बैंगन
नींबू आम केला सेब संतरा अंगूर अनार पपीता तरबूज अमरूद खाना पीना
सोना उठना बैठना चलना दौड़ना बोलना सुनना देखना पढ़ना लिखना सीखना सिखाना
समझना जानना मानना पूछना बताना देना लेना रखना खोलना बंद करना जाना
आना होना रहना मिलना बुलाना भेजना भूलना याद सोचना चाहना ढूँढना बनाना
तोड़ना जोड़ना काटना खींचना धकेलना गिरना उठाना बचाना जीतना हारना खेलना हँसना
रोना गाना नाचना तैरना उड़ना चढ़ना उतरना पकड़ना छोड़ना धोना सुखाना पकाना
जलाना बुझाना जगाना सुलाना दिखाना सुनाना पढ़ाना लिखाना माँगना चुकाना कमाना खरीदना
बेचना गिनना नापना तोलना भरना खाली काम काज नौकरी व्यापार मेहनत तनख्वाह
छुट्टी समय वक्त घंटा मिनट पल दिन रात सुबह दोपहर शाम कल
आज परसों हफ्ता महीना साल सोमवार मंगलवार बुधवार गुरुवार शुक्रवार शनिवार रविवार
माँ पापा भाई बहन दादा दादी नाना नानी चाचा चाची मामा मामी
बेटा बेटी पति पत्नी दोस्त साथी पड़ोसी गुरु शिक्षक विद्यार्थी वकील किसान
मजदूर दुकानदार नाम उम्र पता फोन खेल फिल्म कहानी कविता गीत संगीत
नाच रंग लाल पीला नीला हरा काला सफेद गुलाबी भूरा सिर बाल
आँख कान नाक मुँह दाँत जीभ गला कंधा हाथ उँगली पेट पीठ
पैर घुटना दिल दिमाग खून हड्डी चेहरा सेहत बीमारी दवाई दर्द आराम
नींद सपना हमारा तुम्हारा उनका इसका उसका किसी किसको किसने इसलिए लेकिन
मगर ज़रूर शायद बिल्कुल सिर्फ बस वही यही ऊपर नीचे अंदर बाहर
आगे पीछे पास दूर साथ बिना लिए तक ने हो होगा होगी
होंगे कर करो करता करती करते किया किये गया गयी गये आया
आयी आये जाओ आओ चलो रुको देखो सुनो बोलो बताओ पूछो लिखो
पढ़ो सीखो खाओ पियो सोचो समझो ध्यान लगाओ कोशिश रोज अभ्यास बढ़ो
गलती बेहतर बनो गति सटीकता पाठ स्तर परीक्षा परिणाम अंक औसत प्रगति
लक्ष्य एकाग्रता लय बैठक उँगलियाँ शब्द वाक्य अनुच्छेद अक्षर भाषा हिंदी अंग्रेजी
कुत्ता बिल्ली गाय भैंस घोड़ा हाथी शेर बाघ भालू बंदर हिरण खरगोश
चूहा साँप मछली चिड़िया तोता मोर कौआ कबूतर मक्खी मच्छर चींटी तितली
ऊँट बकरी भेड़ मुर्गा बतख सच्चा झूठा बहादुर होशियार चालाक सीधा टेढ़ा
गोल चौकोर भारी हल्का गरम ठंडा मीठा खट्टा कड़वा नमकीन ताजा बासी
कच्चा पका सस्ता महँगा अमीर गरीब मजबूत कमजोर तंदुरुस्त बीमार जवान बूढ़ा
बच्चा लड़का लड़की आदमी औरत इंसान भगवान पूजा त्योहार दिवाली होली ईद
क्रिसमस मेला बारात शादी जन्मदिन तोहफा मिठाई पटाखे दीपक रोशनी अंधेरा उजाला
चमक छाया जीवन मौत उम्मीद भरोसा सब्र ईमान सच्चाई मेहनती आलसी समझदार
नादान चतुर भोला प्यारा न्यारा अपना पराया नजदीक सामने बगल बीच किनारा
कोना दिशा पूरब पश्चिम उत्तर दक्षिण
""")

    val quotesEnglish: List<String> = listOf(
        "Small steps every day lead to big results.",
        "Slow is smooth, and smooth is fast.",
        "Type with your eyes on the words, not on the keys.",
        "Accuracy first, speed will follow.",
        "A calm mind and relaxed hands type faster than tense ones.",
        "Every mistake is a small lesson in disguise.",
        "Keep your fingers on the home row and trust them.",
        "Practice a little each day, and the progress adds up quietly.",
        "Rhythm matters more than raw speed when you are learning.",
        "Fix the habit first, and the numbers will take care of themselves.",
    )

    val quotesHindi: List<String> = listOf(
        "दिन रात मेहनत कर, सपना सच होगा।",
        "धीरे धीरे चल, मगर चलता रह।",
        "सब कुछ सरल है, बस शुरू कर।",
        "हर दिन थोड़ा थोड़ा सीख।",
        "पहले सही लिखना सीखो, फिर तेज लिखना।",
        "गलती से डरो मत, उससे सीखो।",
        "अभ्यास से हर काम आसान हो जाता है।",
        "शांत मन और ढीले हाथ तेज चलते हैं।",
        "जो रोज चलता है, वह मंजिल तक पहुँच जाता है।",
    )

    val quotesHinglish: List<String> = listOf(
        "Roz thoda practice karo, speed apne aap badh jayegi.",
        "Pehle accuracy, phir speed, yahi sahi tarika hai.",
        "Keyboard ko mat dekho, bas screen par dhyan do.",
        "Galti se mat daro, usse seekho aur aage badho.",
        "Dheere dheere chalo, lekin roz chalo.",
        "Shant mann aur dheele haath tez chalte hain.",
        "Jo roz mehnat karta hai, uska kaam zaroor banta hai.",
        "Ek ek ungli ko apna kaam karne do.",
    )
}
