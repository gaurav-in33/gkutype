package com.gkutype.app.engine

/**
 * Pure typing logic (no Android, no Compose). Same rules as the web preview:
 *  - keep going on a wrong key (or stay on the char when stopOnError is true)
 *  - Space in the middle of a word skips the rest of that word; Space counts as a correct keystroke,
 *    skipped chars are NOT counted in WPM; Backspace undoes a skip
 *  - WPM = (correct chars / 5) / minutes, raw = (keystrokes / 5) / minutes, accuracy = correct keystrokes / keystrokes
 *
 * Every char has a "stamp" (change counter) so the UI only rebuilds the lines that really changed.
 */
class TypingEngine(val text: String) {
    companion object {
        const val PENDING: Byte = 0
        const val CORRECT: Byte = 1
        const val WRONG: Byte = 2
        const val SKIPPED: Byte = 3
    }

    var stopOnError: Boolean = false

    val length: Int = text.length
    val state = ByteArray(length)
    val stamp = IntArray(length + 1)

    var pos: Int = 0
        private set
    var keystrokes: Int = 0
        private set
    var mistakes: Int = 0
        private set
    var correct: Int = 0
        private set
    var skipped: Int = 0
        private set
    var spaces: Int = 0
        private set
    var done: Boolean = false
        private set

    /** Wrong keystrokes per expected char (for weak keys). */
    val missCount = HashMap<Char, Int>()

    private var clock = 0
    private val skips = ArrayList<IntArray>() // [firstSkippedIndex, spaceIndex]

    private fun touch(j: Int) {
        if (j in 0 until length) stamp[j] = ++clock
    }

    private fun touchRange(a: Int, b: Int) {
        var j = a
        while (j <= b) { touch(j); j++ }
    }

    /** Type one char. Returns true if anything changed. */
    fun type(c: Char): Boolean {
        if (done || pos >= length) return false
        if (c == ' ') spaces++
        val e = text[pos]

        // Skip rule: Space in the middle of a word skips the rest of the word.
        if (c == ' ' && e != ' ' && pos >= 1 && text[pos - 1] != ' ') {
            val sp = text.indexOf(' ', pos)
            if (sp >= 0) {
                keystrokes++
                correct++
                val f = pos
                for (j in f until sp) state[j] = SKIPPED
                skipped += sp - f
                state[sp] = CORRECT
                skips.add(intArrayOf(f, sp))
                pos = sp + 1
                touchRange(f, minOf(sp + 1, length - 1))
                if (pos >= length) done = true
                return true
            }
        }

        keystrokes++
        if (c == e) {
            state[pos] = CORRECT
            correct++
        } else {
            mistakes++
            if (e != ' ') missCount[e] = (missCount[e] ?: 0) + 1
            if (stopOnError) {
                touch(pos)
                return true
            }
            state[pos] = WRONG
        }
        val old = pos
        pos++
        touch(old)
        touch(pos)
        if (pos >= length) done = true
        return true
    }

    /** Backspace. Returns true if anything changed. */
    fun backspace(): Boolean {
        if (done || pos == 0) return false
        val old = pos
        pos--
        val t = if (skips.isEmpty()) null else skips[skips.size - 1]
        if (t != null && t[1] == pos) {
            skips.removeAt(skips.size - 1)
            for (j in t[0]..t[1]) state[j] = PENDING
            skipped -= t[1] - t[0]
            correct--
            pos = t[0]
            touchRange(t[0], minOf(t[1] + 1, length - 1))
            touch(old)
            return true
        }
        if (state[pos] == CORRECT) correct--
        state[pos] = PENDING
        touch(pos)
        touch(old)
        return true
    }

    fun wpm(ms: Long): Int = if (ms < 1000) 0 else Math.round(correct / 5.0 / (ms / 60000.0)).toInt()

    fun rawWpm(ms: Long): Int = if (ms < 1000) 0 else Math.round(keystrokes / 5.0 / (ms / 60000.0)).toInt()

    fun accuracy(): Float = if (keystrokes == 0) 100f else (keystrokes - mistakes) * 100f / keystrokes
}
