package com.gkutype.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** One finished test in the history. */
class Rec(val wpm: Int, val acc: Float, val wrong: Int)

/**
 * Real stats, stored only on this phone (SharedPreferences). Written ONCE per finished test
 * (never per keystroke). Nothing is backed up; uninstalling the app resets it.
 */
class StatsStore(ctx: Context) {
    companion object {
        const val MAX_HISTORY = 200
        /** A test needs at least this many keystrokes to count for the "99% accuracy" achievement. */
        const val MIN_KEYS_FOR_ACC = 30
    }

    private val sp = ctx.getSharedPreferences("gku_stats", Context.MODE_PRIVATE)

    /** Newest last, at most MAX_HISTORY. */
    var history by mutableStateOf(loadHistory())
        private set

    /** Wrong keystrokes per expected key (English letters stored lowercase). Feeds weak-key practice. */
    var misses by mutableStateOf(loadMisses())
        private set

    var tests by mutableIntStateOf(sp.getInt("tests", 0))
        private set
    var bestWpm by mutableIntStateOf(sp.getInt("best", 0))
        private set
    var bestAcc by mutableFloatStateOf(sp.getFloat("bestAcc", 0f))
        private set
    private var sumWpm: Long = sp.getLong("sum", 0L)

    val averageWpm: Int get() = if (tests == 0) 0 else Math.round(sumWpm.toDouble() / tests).toInt()
    val lastWpm: Int get() = if (history.isEmpty()) 0 else history[history.size - 1].wpm

    /** Save one finished test. [miss] = expected char -> wrong count for that test. */
    fun record(wpm: Int, acc: Float, wrong: Int, keystrokes: Int, miss: Map<Char, Int>) {
        val h = ArrayList<Rec>(history)
        h.add(Rec(wpm, acc, wrong))
        while (h.size > MAX_HISTORY) h.removeAt(0)
        history = h

        tests += 1
        sumWpm += wpm
        if (wpm > bestWpm) bestWpm = wpm
        if (keystrokes >= MIN_KEYS_FOR_ACC && acc > bestAcc) bestAcc = acc

        if (miss.isNotEmpty()) {
            val m = HashMap<Char, Int>(misses)
            for ((c, n) in miss) {
                val k = if (c.code < 128) c.lowercaseChar() else c
                m[k] = (m[k] ?: 0) + n
            }
            misses = m
        }

        sp.edit()
            .putString("hist", encodeHistory(h))
            .putString("miss", encodeMisses(misses))
            .putInt("tests", tests)
            .putInt("best", bestWpm)
            .putFloat("bestAcc", bestAcc)
            .putLong("sum", sumWpm)
            .apply()
    }

    // ---- tiny text format: "wpm,accTenths,wrong;..." and "charCode:count;..." ----

    private fun encodeHistory(h: List<Rec>): String {
        val sb = StringBuilder()
        for (r in h) {
            sb.append(r.wpm).append(',').append(Math.round(r.acc * 10f)).append(',').append(r.wrong).append(';')
        }
        return sb.toString()
    }

    private fun loadHistory(): List<Rec> {
        val out = ArrayList<Rec>()
        val s = sp.getString("hist", "") ?: ""
        for (part in s.split(';')) {
            if (part.isEmpty()) continue
            try {
                val f = part.split(',')
                out.add(Rec(f[0].toInt(), f[1].toInt() / 10f, f[2].toInt()))
            } catch (e: Exception) {
                // skip a damaged entry
            }
        }
        return out
    }

    private fun encodeMisses(m: Map<Char, Int>): String {
        val sb = StringBuilder()
        for ((c, n) in m) sb.append(c.code).append(':').append(n).append(';')
        return sb.toString()
    }

    private fun loadMisses(): Map<Char, Int> {
        val out = HashMap<Char, Int>()
        val s = sp.getString("miss", "") ?: ""
        for (part in s.split(';')) {
            if (part.isEmpty()) continue
            try {
                val f = part.split(':')
                out[f[0].toInt().toChar()] = f[1].toInt()
            } catch (e: Exception) {
                // skip a damaged entry
            }
        }
        return out
    }
}
